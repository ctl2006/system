package com.example.controller;

import com.example.common.Result;
import com.example.entity.Borrow;
import com.example.service.BorrowService;
import com.github.pagehelper.PageInfo;
import jakarta.annotation.Resource;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 图书前端操作接口
 **/
//Spring Boot 的魔法注解。它告诉框架：“这个类是一个控制器，它里面的方法都会返回数据给前端，不用去渲染网页页面。”
@RestController
//它设定了一个路由前缀。当前端请求的网址以 /borrow 开头时，框架就会把这个请求交给这个控制器来处理。
@RequestMapping("/borrow")
public class BorrowController {

    @Resource
    private BorrowService borrowService;

    /**
     * 新增
     */
    //规定前端必须用 POST 请求方式访问 /borrow/add 这个网址。
    @PostMapping("/add")
    public Result add(@RequestBody Borrow borrow) {
        borrowService.add(borrow);
        return Result.success();
    }

    /**
     * 删除
     */
    @DeleteMapping("/delete/{id}")
    public Result deleteById(@PathVariable Integer id) {
        borrowService.deleteById(id);
        return Result.success();
    }

    /**
     * 修改
     */
    @PutMapping("/update")
    public Result updateById(@RequestBody Borrow borrow) {
        borrowService.updateById(borrow);
        return Result.success();
    }

    /**
     * 根据ID查询
     */
    @GetMapping("/selectById/{id}")
    public Result selectById(@PathVariable Integer id) {
        Borrow borrow = borrowService.selectById(id);
        return Result.success(borrow);
    }

    /**
     * 查询所有
     */
    @GetMapping("/selectAll")
    public Result selectAll(Borrow borrow) {
        List<Borrow> list = borrowService.selectAll(borrow);
        return Result.success(list);
    }

    /**
     * 分页查询
     */
    @GetMapping("/selectPage")
    public Result selectPage(Borrow borrow,
                             @RequestParam(defaultValue = "1") Integer pageNum,
                             @RequestParam(defaultValue = "10") Integer pageSize) {
        PageInfo<Borrow> page = borrowService.selectPage(borrow, pageNum, pageSize);
        return Result.success(page);
    }

}