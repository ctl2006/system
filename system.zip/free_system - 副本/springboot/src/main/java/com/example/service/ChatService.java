package com.example.service;

import cn.hutool.core.date.DateUtil;
import com.example.entity.Chat;
import com.example.entity.Chat;
import com.example.mapper.ChatMapper;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import jakarta.annotation.Resource;
import org.springframework.stereotype.Service;

import java.util.List;


@Service
public class ChatService {

    @Resource
    private ChatMapper chatMapper;

    /**
     * 新增
     */
    public void add(Chat chat) {
        chat.setTime(DateUtil.now());
        chatMapper.insert(chat);
    }

    /**
     * 删除
     */
    public void deleteById(Integer id) {
        chatMapper.deleteById(id);
    }

    /**
     * 修改
     */
    public void updateById(Chat chat) {
        chatMapper.updateById(chat);
    }

    /**
     * 根据ID查询
     */
    public Chat selectById(Integer id) {
        return chatMapper.selectById(id);
    }

    /**
     * 查询所有
     */
    public List<Chat> selectAll(Chat chat) {
        return chatMapper.selectAll(chat);
    }

    /**
     * 分页查询
     */
    public PageInfo<Chat> selectPage(Chat chat, Integer pageNum, Integer pageSize) {
        PageHelper.startPage(pageNum, pageSize);
        List<Chat> list = chatMapper.selectAll(chat);
        for (Chat dbChat : list){
            Chat cm = new Chat();
            cm.setFid(dbChat.getId());
            List<Chat> children = chatMapper.selectAll(cm);
            dbChat.setChildren(children);
        }
        return PageInfo.of(list);
    }

}