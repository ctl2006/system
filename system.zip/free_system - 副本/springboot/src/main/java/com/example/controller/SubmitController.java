package com.example.controller;

import com.example.common.Result;
import com.example.entity.Submit;
import com.example.service.SubmitService;
import com.github.pagehelper.PageInfo;
import jakarta.annotation.Resource;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 图书前端操作接口
 **/
//Spring Boot 的魔法注解。它告诉框架：“这个类是一个控制器，它里面的方法都会返回数据给前端，不用去渲染网页页面。”
@RestController
//它设定了一个路由前缀。当前端请求的网址以 /submit 开头时，框架就会把这个请求交给这个控制器来处理。
@RequestMapping("/submit")
public class SubmitController {

    @Resource
    private SubmitService submitService;

    /**
     * 新增
     */
    //规定前端必须用 POST 请求方式访问 /submit/add 这个网址。
    @PostMapping("/add")
    public Result add(@RequestBody Submit submit) {
        submitService.add(submit);
        return Result.success();
    }

    /**
     * 删除
     */
    @DeleteMapping("/delete/{id}")
    public Result deleteById(@PathVariable Integer id) {
        submitService.deleteById(id);
        return Result.success();
    }

    /**
     * 修改
     */
    @PutMapping("/update")
    public Result updateById(@RequestBody Submit submit) {
        submitService.updateById(submit);
        return Result.success();
    }

    /**
     * 根据ID查询
     */
    @GetMapping("/selectById/{id}")
    public Result selectById(@PathVariable Integer id) {
        Submit submit = submitService.selectById(id);
        return Result.success(submit);
    }

    /**
     * 查询所有
     */
    @GetMapping("/selectAll")
    public Result selectAll(Submit submit) {
        List<Submit> list = submitService.selectAll(submit);
        return Result.success(list);
    }

    /**
     * 分页查询
     */
    @GetMapping("/selectPage")
    public Result selectPage(Submit submit,
                             @RequestParam(defaultValue = "1") Integer pageNum,
                             @RequestParam(defaultValue = "10") Integer pageSize) {
        PageInfo<Submit> page = submitService.selectPage(submit, pageNum, pageSize);
        return Result.success(page);
    }

}