package com.example.mapper;

import com.example.entity.BookContent;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Select;

import java.util.List;

/**
 * 操作bookContent相关数据接口
*/
public interface BookContentMapper {

    /**
      * 新增
    */
    void insert(BookContent bookContent);

    /**
      * 删除
    */
    @Delete("delete from book_content where id = #{id}")
    void deleteById(Integer id);

    /**
      * 修改
    */
    void updateById(BookContent bookContent);

    /**
      * 根据ID查询
    */
    @Select("select * from book_content where id = #{id}")
    BookContent selectById(Integer id);

    /**
      * 查询所有
    */
    List<BookContent> selectAll(BookContent bookContent);


}