package com.example.entity;

/**
 * 章节实体类
*/
public class Chapter {

    /** ID */
    private Integer id;
    /** 章节名 */
    private String name;
    /** 书id */
    private Integer bookId;
    /** 书名 */
    private String bookName;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getBookId() {
        return bookId;
    }

    public void setBookId(Integer bookId) {
        this.bookId = bookId;
    }

    public String getBookName() {
        return bookName;
    }

    public void setBookName(String bookName) {
        this.bookName = bookName;
    }
}