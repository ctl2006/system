package com.example.controller;

import com.example.common.Result;
import com.example.entity.HotelReserve;
import com.example.service.HotelReserveService;
import com.github.pagehelper.PageInfo;
import jakarta.annotation.Resource;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 图书前端操作接口
 **/
//Spring Boot 的魔法注解。它告诉框架：“这个类是一个控制器，它里面的方法都会返回数据给前端，不用去渲染网页页面。”
@RestController
//它设定了一个路由前缀。当前端请求的网址以 /hotelReserve 开头时，框架就会把这个请求交给这个控制器来处理。
@RequestMapping("/hotelReserve")
public class HotelReserveController {

    @Resource
    private HotelReserveService hotelReserveService;

    /**
     * 新增
     */
    //规定前端必须用 POST 请求方式访问 /hotelReserve/add 这个网址。
    @PostMapping("/add")
    public Result add(@RequestBody HotelReserve hotelReserve) {
        hotelReserveService.add(hotelReserve);
        return Result.success();
    }

    /**
     * 删除
     */
    @DeleteMapping("/delete/{id}")
    public Result deleteById(@PathVariable Integer id) {
        hotelReserveService.deleteById(id);
        return Result.success();
    }

    /**
     * 修改
     */
    @PutMapping("/update")
    public Result updateById(@RequestBody HotelReserve hotelReserve) {
        hotelReserveService.updateById(hotelReserve);
        return Result.success();
    }

    /**
     * 根据ID查询
     */
    @GetMapping("/selectById/{id}")
    public Result selectById(@PathVariable Integer id) {
        HotelReserve hotelReserve = hotelReserveService.selectById(id);
        return Result.success(hotelReserve);
    }

    /**
     * 查询所有
     */
    @GetMapping("/selectAll")
    public Result selectAll(HotelReserve hotelReserve) {
        List<HotelReserve> list = hotelReserveService.selectAll(hotelReserve);
        return Result.success(list);
    }

    /**
     * 分页查询
     */
    @GetMapping("/selectPage")
    public Result selectPage(HotelReserve hotelReserve,
                             @RequestParam(defaultValue = "1") Integer pageNum,
                             @RequestParam(defaultValue = "10") Integer pageSize) {
        PageInfo<HotelReserve> page = hotelReserveService.selectPage(hotelReserve, pageNum, pageSize);
        return Result.success(page);
    }

}