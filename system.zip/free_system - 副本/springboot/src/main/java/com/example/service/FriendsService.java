package com.example.service;

import com.example.entity.Friends;
import com.example.entity.User;
import com.example.mapper.FriendsMapper;
import com.example.mapper.UserMapper;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import jakarta.annotation.Resource;
import org.springframework.stereotype.Service;

import java.util.List;


@Service
public class FriendsService {

    @Resource
    private FriendsMapper friendsMapper;
    @Resource
    private UserMapper userMapper;

    /**
     * 新增
     */
    public void add(Friends friends) {
        friendsMapper.insert(friends);
    }

    /**
     * 删除
     */
    public void deleteById(Integer id) {
        friendsMapper.deleteById(id);
    }

    /**
     * 修改
     */
    public void updateById(Friends friends) {
        friendsMapper.updateById(friends);
    }

    /**
     * 根据ID查询
     */
    public Friends selectById(Integer id) {
        return friendsMapper.selectById(id);
    }

    /**
     * 查询所有
     */
    public List<Friends> selectAll(Friends friends) {
        return friendsMapper.selectAll(friends);
    }

    /**
     * 分页查询
     */
    public PageInfo<Friends> selectPage(Friends friends, Integer pageNum, Integer pageSize) {
        PageHelper.startPage(pageNum, pageSize);
        List<Friends> list = friendsMapper.selectAll(friends);
        for (Friends dbfriend : list) {
            User fromUser = userMapper.selectById(dbfriend.getFromId());
            User toUser = userMapper.selectById(dbfriend.getToId());
            dbfriend.setFromUser(fromUser);
            dbfriend.setToUser(toUser);
        }
        return PageInfo.of(list);
    }

    public PageInfo<Friends> selectMyFriendsPage(Friends friends, Integer pageNum, Integer pageSize) {
        PageHelper.startPage(pageNum, pageSize);
        List<Friends> list = friendsMapper.selectMyFriendsPage(friends.getUserId());
        for (Friends dbfriend : list) {
            User fromUser = userMapper.selectById(dbfriend.getFromId());
            User toUser = userMapper.selectById(dbfriend.getToId());
            dbfriend.setFromUser(fromUser);
            dbfriend.setToUser(toUser);
        }
        return PageInfo.of(list);

    }

    public List<Friends> check(Friends friends) {
        return friendsMapper.check(friends.getFromId(), friends.getToId());
    }

}

