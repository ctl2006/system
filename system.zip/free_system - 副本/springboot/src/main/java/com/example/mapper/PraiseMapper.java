package com.example.mapper;

import com.example.entity.Praise;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Select;

import java.util.List;

/**
 * 操作praise相关数据接口
*/
public interface PraiseMapper {

    /**
      * 新增
    */
    void insert(Praise praise);

    /**
      * 删除
    */
    @Delete("delete from praise where id = #{id}")
    void deleteById(Integer id);

    /**
      * 修改
    */
    void updateById(Praise praise);

    /**
      * 根据ID查询
    */
    @Select("select * from praise where id = #{id}")
    Praise selectById(Integer id);

    /**
      * 查询所有
    */
    List<Praise> selectAll(Praise praise);


}