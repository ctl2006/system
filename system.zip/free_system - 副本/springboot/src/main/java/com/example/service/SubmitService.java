package com.example.service;

import cn.hutool.core.collection.CollectionUtil;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.ObjectUtil;
import com.example.entity.Homework;
import com.example.entity.Submit;
import com.example.entity.User;
import com.example.exception.CustomException;
import com.example.mapper.HomeworkMapper;
import com.example.mapper.SubmitMapper;
import com.example.mapper.UserMapper;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import jakarta.annotation.Resource;
import org.springframework.stereotype.Service;

import java.util.List;


@Service
public class SubmitService {

    @Resource
    private SubmitMapper submitMapper;

    /**
     * 新增
     */
    public void add(Submit submit) {
        List<Submit> list = submitMapper.selectAll(submit);
        if (CollectionUtil.isNotEmpty(list)) {
            Submit dbSubmit = list.get(0);
            if (ObjectUtil.isNotNull(dbSubmit.getScore())) {
                throw new CustomException("该作业已批改，不能重复提交");
            }
            else {
                dbSubmit.setTime(DateUtil.now());
                dbSubmit.setFile(submit.getFile());
                submitMapper.updateById(dbSubmit);
            }
        }
        else {
            submit.setTime(DateUtil.now());
            submitMapper.insert(submit);
        }
    }

    /**
     * 删除
     */
    public void deleteById(Integer id) {
        submitMapper.deleteById(id);
    }

    /**
     * 修改
     */
    public void updateById(Submit submit) {
        submitMapper.updateById(submit);
    }

    /**
     * 根据ID查询
     */
    public Submit selectById(Integer id) {
        return submitMapper.selectById(id);
    }

    /**
     * 查询所有
     */
    public List<Submit> selectAll(Submit submit) {
        return submitMapper.selectAll(submit);
    }

    /**
     * 分页查询
     */
    public PageInfo<Submit> selectPage(Submit submit, Integer pageNum, Integer pageSize) {
        PageHelper.startPage(pageNum, pageSize);
        List<Submit> list = submitMapper.selectAll(submit);
        return PageInfo.of(list);
    }

}