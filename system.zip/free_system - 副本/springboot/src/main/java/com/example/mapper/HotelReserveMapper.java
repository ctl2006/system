package com.example.mapper;

import com.example.entity.HotelReserve;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Select;

import java.util.List;

/**
 * 操作hotelReserve相关数据接口
*/
public interface HotelReserveMapper {

    /**
      * 新增
    */
    void insert(HotelReserve hotelReserve);

    /**
      * 删除
    */
    @Delete("delete from hotel_reserve where id = #{id}")
    void deleteById(Integer id);

    /**
      * 修改
    */
    void updateById(HotelReserve hotelReserve);

    /**
      * 根据ID查询
    */
    @Select("select * from hotel_reserve where id = #{id}")
    HotelReserve selectById(Integer id);

    /**
      * 查询所有
    */
    List<HotelReserve> selectAll(HotelReserve hotelReserve);


}