package com.example.service;

import com.example.entity.Homework;
import com.example.mapper.HomeworkMapper;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import jakarta.annotation.Resource;
import org.springframework.stereotype.Service;

import java.util.List;

/**

 * 图书业务处理
 **/
@Service
public class HomeworkService {

    @Resource
    private HomeworkMapper homeworkMapper;

    /**
     * 新增
     */
    public void add(Homework homework) {
        homeworkMapper.insert(homework);
    }

    /**
     * 删除
     */
    public void deleteById(Integer id) {
        homeworkMapper.deleteById(id);
    }

    /**
     * 修改
     */
    public void updateById(Homework homework) {
        homeworkMapper.updateById(homework);
    }

    /**
     * 根据ID查询
     */
    public Homework selectById(Integer id) {
        return homeworkMapper.selectById(id);
    }

    /**
     * 查询所有
     */
    public List<Homework> selectAll(Homework homework) {
        return homeworkMapper.selectAll(homework);
    }

    /**
     * 分页查询
     */
    public PageInfo<Homework> selectPage(Homework homework, Integer pageNum, Integer pageSize) {
        PageHelper.startPage(pageNum, pageSize);
        List<Homework> list = homeworkMapper.selectAll(homework);
        return PageInfo.of(list);
    }

}