package com.example.mapper;

import com.example.entity.Friends;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Select;

import java.util.List;

/**
 * 操作friends相关数据接口
*/
public interface FriendsMapper {

    /**
      * 新增
    */
    void insert(Friends friends);

    /**
      * 删除
    */
    @Delete("delete from friends where id = #{id}")
    void deleteById(Integer id);

    /**
      * 修改
    */
    void updateById(Friends friends);

    /**
      * 根据ID查询
    */
    @Select("select * from friends where id = #{id}")
    Friends selectById(Integer id);

    /**
      * 查询所有
    */
    List<Friends> selectAll(Friends friends);


    @Select("select * from `friends` where ( from_id = #{userId} or to_id = #{userId} ) and status = '已同意'")
    List<Friends> selectMyFriendsPage(Integer userId);

    @Select("select * from `friends` where (( from_id = #{fromId} and to_id = #{toId} ) or ( from_id = #{toId} and to_id = #{fromId} )) and status != '已拒绝'")
    List<Friends> check(Integer fromId, Integer toId);


}