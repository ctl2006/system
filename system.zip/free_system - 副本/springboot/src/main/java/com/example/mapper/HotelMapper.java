package com.example.mapper;

import com.example.entity.Hotel;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Select;

import java.util.List;

/**
 * 操作hotel相关数据接口
*/
public interface HotelMapper {

    /**
      * 新增
    */
    void insert(Hotel hotel);

    /**
      * 删除
    */
    @Delete("delete from hotel where id = #{id}")
    void deleteById(Integer id);

    /**
      * 修改
    */
    void updateById(Hotel hotel);

    /**
      * 根据ID查询
    */
    @Select("select * from hotel where id = #{id}")
    Hotel selectById(Integer id);

    /**
      * 查询所有
    */
    List<Hotel> selectAll(Hotel hotel);


}