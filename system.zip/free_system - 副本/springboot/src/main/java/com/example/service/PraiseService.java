package com.example.service;

import cn.hutool.core.collection.CollectionUtil;
import cn.hutool.core.date.DateUtil;
import com.example.entity.Praise;
import com.example.mapper.PraiseMapper;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import jakarta.annotation.Resource;
import org.springframework.stereotype.Service;

import java.util.List;

/**

 * 点赞业务处理
 **/
@Service
public class PraiseService {

    @Resource
    private PraiseMapper praiseMapper;

    /**
     * 新增
     */
    public void add(Praise praise) {
        List<Praise> praises = praiseMapper.selectAll(praise);
        if(CollectionUtil.isNotEmpty(praises)){
            praiseMapper.deleteById(praises.get(0).getId());
        }
        else {
            praise.setTime(DateUtil.now());
            praiseMapper.insert(praise);
        }
    }

    /**
     * 删除
     */
    public void deleteById(Integer id) {
        praiseMapper.deleteById(id);
    }

    /**
     * 修改
     */
    public void updateById(Praise praise) {
        praiseMapper.updateById(praise);
    }

    /**
     * 根据ID查询
     */
    public Praise selectById(Integer id) {
        return praiseMapper.selectById(id);
    }

    /**
     * 查询所有
     */
    public List<Praise> selectAll(Praise praise) {
        return praiseMapper.selectAll(praise);
    }

    /**
     * 分页查询
     */
    public PageInfo<Praise> selectPage(Praise praise, Integer pageNum, Integer pageSize) {
        PageHelper.startPage(pageNum, pageSize);
        List<Praise> list = praiseMapper.selectAll(praise);
        return PageInfo.of(list);
    }

}