package com.example.mapper;

import com.example.entity.Submit;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Select;

import java.util.List;

/**
 * 操作submit相关数据接口
*/
public interface SubmitMapper {

    /**
      * 新增
    */
    void insert(Submit submit);

    /**
      * 删除
    */
    @Delete("delete from submit where id = #{id}")
    void deleteById(Integer id);

    /**
      * 修改
    */
    void updateById(Submit submit);

    /**
      * 根据ID查询
    */
    @Select("select * from submit where id = #{id}")
    Submit selectById(Integer id);

    /**
      * 查询所有
    */
    List<Submit> selectAll(Submit submit);


}