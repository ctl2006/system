package com.example.mapper;

import com.example.entity.Chat;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Select;

import java.util.List;

/**
 * 操作chat相关数据接口
*/
public interface ChatMapper {

    /**
      * 新增
    */
    void insert(Chat chat);

    /**
      * 删除
    */
    @Delete("delete from chat where id = #{id}")
    void deleteById(Integer id);

    /**
      * 修改
    */
    void updateById(Chat chat);

    /**
      * 根据ID查询
    */
    @Select("select * from chat where id = #{id}")
    Chat selectById(Integer id);

    /**
      * 查询所有
    */
    List<Chat> selectAll(Chat chat);


}