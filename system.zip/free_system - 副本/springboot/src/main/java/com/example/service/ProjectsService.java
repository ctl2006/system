package com.example.service;

import com.example.entity.Projects;
import com.example.mapper.ProjectsMapper;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import jakarta.annotation.Resource;
import org.springframework.stereotype.Service;

import java.util.List;

/**

 * 体检业务处理
 **/
@Service
public class ProjectsService {

    @Resource
    private ProjectsMapper projectsMapper;

    /**
     * 新增
     */
    public void add(Projects projects) {
        projectsMapper.insert(projects);
    }

    /**
     * 删除
     */
    public void deleteById(Integer id) {
        projectsMapper.deleteById(id);
    }

    /**
     * 修改
     */
    public void updateById(Projects projects) {
        projectsMapper.updateById(projects);
    }

    /**
     * 根据ID查询
     */
    public Projects selectById(Integer id) {
        return projectsMapper.selectById(id);
    }

    /**
     * 查询所有
     */
    public List<Projects> selectAll(Projects projects) {
        return projectsMapper.selectAll(projects);
    }

    /**
     * 分页查询
     */
    public PageInfo<Projects> selectPage(Projects projects, Integer pageNum, Integer pageSize) {
        PageHelper.startPage(pageNum, pageSize);
        List<Projects> list = projectsMapper.selectAll(projects);
        return PageInfo.of(list);
    }

}