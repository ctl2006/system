package com.example.entity;

/**
 * 体检预约
*/
public class Reserve {

    /** ID */
    private Integer id;
    private Integer userId;
    private Integer projectsId;
    private String time;
    private String status;

    private String userName;
    private String projectsName;
    private Double projectsPrice;

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getProjectsId() {
        return projectsId;
    }

    public void setProjectsId(Integer projectsId) {
        this.projectsId = projectsId;
    }

    public String getProjectsName() {
        return projectsName;
    }

    public void setProjectsName(String projectsName) {
        this.projectsName = projectsName;
    }

    public Double getProjectsPrice() {
        return projectsPrice;
    }

    public void setProjectsPrice(Double projectsPrice) {
        this.projectsPrice = projectsPrice;
    }
}