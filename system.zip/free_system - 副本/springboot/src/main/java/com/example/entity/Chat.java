package com.example.entity;

import java.util.List;

/**
 * 用户实体类
*/
public class Chat {

    /** ID */
    private Integer id;
    private String time;
    private String content;
    /** 图片 */
    private String img;
    private String userAvatar;
    private String userName;
    private Integer userId;
    private Integer fid;
    private List<Chat> children;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public String getImg() {
        return img;
    }

    public void setImg(String img) {
        this.img = img;
    }

    public Integer getFid() {
        return fid;
    }

    public void setFid(Integer fid) {
        this.fid = fid;
    }

    public String getUserAvatar() {
        return userAvatar;
    }

    public void setUserAvatar(String userAvatar) {
        this.userAvatar = userAvatar;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public List<Chat> getChildren() {
        return children;
    }

    public void setChildren(List<Chat> children) {
        this.children = children;
    }
}