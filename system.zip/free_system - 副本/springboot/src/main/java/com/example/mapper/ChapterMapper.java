package com.example.mapper;

import com.example.entity.Chapter;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Select;

import java.util.List;

/**
 * 操作chapter相关数据接口
*/
public interface ChapterMapper {

    /**
      * 新增
    */
    void insert(Chapter chapter);

    /**
      * 删除
    */
    @Delete("delete from chapter where id = #{id}")
    void deleteById(Integer id);

    /**
      * 修改
    */
    void updateById(Chapter chapter);

    /**
      * 根据ID查询
    */
    @Select("select * from chapter where id = #{id}")
    Chapter selectById(Integer id);

    /**
      * 查询所有
    */
    List<Chapter> selectAll(Chapter chapter);


}