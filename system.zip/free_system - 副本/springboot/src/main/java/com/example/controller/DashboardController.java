package com.example.controller;


import cn.hutool.core.date.DateField;
import cn.hutool.core.date.DateTime;
import cn.hutool.core.date.DateUtil;
import com.example.common.Result;
import com.example.entity.Article;
import com.example.entity.Book;
import com.example.entity.Borrow;
import com.example.service.ArticleService;
import com.example.service.BookService;
import com.example.service.BorrowService;
import jakarta.annotation.Resource;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.*;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/dashboard")
public class DashboardController {

    @Resource
    private ArticleService articleService;
    @Resource
    private BookService bookService;
    @Resource
    private BorrowService borrowService;


    public DashboardController(ArticleService articleService) {
        this.articleService = articleService;
    }

    @GetMapping("/line")
    public Result line() {

        List<Long> yList = new ArrayList<>();

        // 获取最近7天的数据（年-月-日）放在xList里
        Date today = new Date();
        DateTime start = DateUtil.offsetDay(today, -30);
        List<String> xList = DateUtil.rangeToList(start, today, DateField.DAY_OF_YEAR)
                .stream()
                .map(DateUtil::formatDate)
                .toList();

        List<Article> list = articleService.selectAll(new Article());
        for (String day : xList) {
            long count = list.stream().filter(x -> x.getTime().contains(day)).count();
            yList.add(count);
        }

        Map<String, Object> map = new HashMap<>();
        map.put("x", xList);
        map.put("y", yList);
        return Result.success(map);
    }

    @GetMapping("/bar")
    public Result bar() {

        List<Long> yList = new ArrayList<>();
        List<Book> books = bookService.selectAll(new Book());
        List<String> xList = books.stream().map(Book::getName).collect(Collectors.toList());

        List<Borrow> borrows = borrowService.selectAll(new Borrow());

        for (String name : xList) {
            long count = borrows.stream().filter(x -> x.getBookName().equals(name)).count();
            yList.add(count);
        }

        Map<String, Object> map = new HashMap<>();
        map.put("x", xList);
        map.put("y", yList);
        return Result.success(map);
    }

    @GetMapping("/pie")
    public Result pie() {
        List<Map<String, Object>> list = new ArrayList<>();
        List<Book> books = bookService.selectAll(new Book());
        Map<String, Long> map = books.stream().collect(Collectors.groupingBy(Book::getPublishing, Collectors.counting()));

        for (String key : map.keySet()) {
            Map<String, Object> item = new HashMap<>();
            item.put("name", key);
            item.put("value", map.get(key));
            list.add(item);
        }
        return Result.success(list);
    }
}
