package com.example.service;

import cn.hutool.core.date.DateUtil;
import com.example.entity.Book;
import com.example.entity.Orders;
import com.example.entity.User;
import com.example.exception.CustomException;
import com.example.mapper.BookMapper;
import com.example.mapper.OrdersMapper;
import com.example.mapper.UserMapper;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import jakarta.annotation.Resource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;

/**

 * 订单业务处理
 **/
@Service
public class OrdersService {

    @Resource
    private OrdersMapper ordersMapper;
    @Resource
    private BookMapper bookMapper;
    @Resource
    private UserMapper userMapper;

    /**
     * 新增
     */
    public void add(Orders orders) {

        Book book = bookMapper.selectById(orders.getRelId());
        if (book.getNum() < orders.getNum()) {
            throw new CustomException("库存不足");
        }
        orders.setOrderNo(DateUtil.format(new Date(), "yyyyMMddHHmmss"));
        orders.setTime(DateUtil.now());
        orders.setPrice(orders.getNum() * book.getPrice());

        User user = userMapper.selectById(orders.getUserId());
        if (user.getAccount() < orders.getPrice()) {
            throw new CustomException("余额不足，请到个人中心充值");
        }
        user.setAccount(user.getAccount() - orders.getPrice());
        userMapper.updateById(user);

        ordersMapper.insert(orders);

        book.setNum(book.getNum() - orders.getNum());
        bookMapper.updateById(book);
    }

    /**
     * 删除
     */
    public void deleteById(Integer id) {
        ordersMapper.deleteById(id);
    }

    /**
     * 修改
     */
    public void updateById(Orders orders) {
        ordersMapper.updateById(orders);
    }

    /**
     * 根据ID查询
     */
    public Orders selectById(Integer id) {
        return ordersMapper.selectById(id);
    }

    /**
     * 查询所有
     */
    public List<Orders> selectAll(Orders orders) {
        return ordersMapper.selectAll(orders);
    }

    /**
     * 分页查询
     */
    public PageInfo<Orders> selectPage(Orders orders, Integer pageNum, Integer pageSize) {
        PageHelper.startPage(pageNum, pageSize);
        List<Orders> list = ordersMapper.selectAll(orders);
        return PageInfo.of(list);
    }

}