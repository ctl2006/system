package com.example.mapper;

import com.example.entity.Projects;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Select;

import java.util.List;

/**
 * 操作projects相关数据接口
*/
public interface ProjectsMapper {

    /**
      * 新增
    */
    void insert(Projects projects);

    /**
      * 删除
    */
    @Delete("delete from projects where id = #{id}")
    void deleteById(Integer id);

    /**
      * 修改
    */
    void updateById(Projects projects);

    /**
      * 根据ID查询
    */
    @Select("select * from projects where id = #{id}")
    Projects selectById(Integer id);

    /**
      * 查询所有
    */
    List<Projects> selectAll(Projects projects);


}