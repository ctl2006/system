package com.example.mapper;

import com.example.entity.Reserve;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Select;

import java.util.List;

/**
 * 操作reserve相关数据接口
*/
public interface ReserveMapper {

    /**
      * 新增
    */
    void insert(Reserve reserve);

    /**
      * 删除
    */
    @Delete("delete from reserve where id = #{id}")
    void deleteById(Integer id);

    /**
      * 修改
    */
    void updateById(Reserve reserve);

    /**
      * 根据ID查询
    */
    @Select("select * from reserve where id = #{id}")
    Reserve selectById(Integer id);

    /**
      * 查询所有
    */
    List<Reserve> selectAll(Reserve reserve);


}