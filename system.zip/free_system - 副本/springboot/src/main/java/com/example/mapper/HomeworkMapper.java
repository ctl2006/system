package com.example.mapper;

import com.example.entity.Homework;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Select;

import java.util.List;

/**
 * 操作homework相关数据接口
*/
public interface HomeworkMapper {

    /**
      * 新增
    */
    void insert(Homework homework);

    /**
      * 删除
    */
    @Delete("delete from homework where id = #{id}")
    void deleteById(Integer id);

    /**
      * 修改
    */
    void updateById(Homework homework);

    /**
      * 根据ID查询
    */
    @Select("select * from homework where id = #{id}")
    Homework selectById(Integer id);

    /**
      * 查询所有
    */
    List<Homework> selectAll(Homework homework);


}