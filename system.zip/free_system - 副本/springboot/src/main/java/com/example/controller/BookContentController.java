package com.example.controller;

import com.example.common.Result;
import com.example.entity.BookContent;
import com.example.service.BookContentService;
import com.github.pagehelper.PageInfo;
import jakarta.annotation.Resource;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 章节前端操作接口
 **/
//Spring Boot 的魔法注解。它告诉框架：“这个类是一个控制器，它里面的方法都会返回数据给前端，不用去渲染网页页面。”
@RestController
//它设定了一个路由前缀。当前端请求的网址以 /bookContent 开头时，框架就会把这个请求交给这个控制器来处理。
@RequestMapping("/bookContent")
public class BookContentController {

    @Resource
    private BookContentService bookContentService;

    /**
     * 新增
     */
    //规定前端必须用 POST 请求方式访问 /bookContent/add 这个网址。
    @PostMapping("/add")
    public Result add(@RequestBody BookContent bookContent) {
        bookContentService.add(bookContent);
        return Result.success();
    }

    /**
     * 删除
     */
    @DeleteMapping("/delete/{id}")
    public Result deleteById(@PathVariable Integer id) {
        bookContentService.deleteById(id);
        return Result.success();
    }

    /**
     * 修改
     */
    @PutMapping("/update")
    public Result updateById(@RequestBody BookContent bookContent) {
        bookContentService.updateById(bookContent);
        return Result.success();
    }

    /**
     * 根据ID查询
     */
    @GetMapping("/selectById/{id}")
    public Result selectById(@PathVariable Integer id) {
        BookContent bookContent = bookContentService.selectById(id);
        return Result.success(bookContent);
    }

    /**
     * 查询所有
     */
    @GetMapping("/selectAll")
    public Result selectAll(BookContent bookContent) {
        List<BookContent> list = bookContentService.selectAll(bookContent);
        return Result.success(list);
    }

    /**
     * 分页查询
     */
    @GetMapping("/selectPage")
    public Result selectPage(BookContent bookContent,
                             @RequestParam(defaultValue = "1") Integer pageNum,
                             @RequestParam(defaultValue = "10") Integer pageSize) {
        PageInfo<BookContent> page = bookContentService.selectPage(bookContent, pageNum, pageSize);
        return Result.success(page);
    }

}