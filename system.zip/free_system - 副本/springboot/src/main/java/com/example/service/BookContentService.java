package com.example.service;

import com.example.entity.BookContent;
import com.example.mapper.BookContentMapper;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import jakarta.annotation.Resource;
import org.springframework.stereotype.Service;

import java.util.List;

/**

 * 图书业务处理
 **/
@Service
public class BookContentService {

    @Resource
    private BookContentMapper bookContentMapper;

    /**
     * 新增
     */
    public void add(BookContent bookContent) {
        bookContentMapper.insert(bookContent);
    }

    /**
     * 删除
     */
    public void deleteById(Integer id) {
        bookContentMapper.deleteById(id);
    }

    /**
     * 修改
     */
    public void updateById(BookContent bookContent) {
        bookContentMapper.updateById(bookContent);
    }

    /**
     * 根据ID查询
     */
    public BookContent selectById(Integer id) {
        return bookContentMapper.selectById(id);
    }

    /**
     * 查询所有
     */
    public List<BookContent> selectAll(BookContent bookContent) {
        return bookContentMapper.selectAll(bookContent);
    }

    /**
     * 分页查询
     */
    public PageInfo<BookContent> selectPage(BookContent bookContent, Integer pageNum, Integer pageSize) {
        PageHelper.startPage(pageNum, pageSize);
        List<BookContent> list = bookContentMapper.selectAll(bookContent);
        return PageInfo.of(list);
    }

}