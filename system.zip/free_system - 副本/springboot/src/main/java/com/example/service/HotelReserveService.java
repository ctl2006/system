package com.example.service;

import cn.hutool.core.util.ObjectUtil;
import com.example.entity.Hotel;
import com.example.entity.Projects;
import com.example.entity.HotelReserve;
import com.example.entity.User;
import com.example.exception.CustomException;
import com.example.mapper.HotelMapper;
import com.example.mapper.ProjectsMapper;
import com.example.mapper.HotelReserveMapper;
import com.example.mapper.UserMapper;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import jakarta.annotation.Resource;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Objects;

/**

 * 预约业务处理
 **/
@Service
public class HotelReserveService {

    @Resource
    private HotelReserveMapper hotelReserveMapper;
    @Resource
    private HotelMapper hotelMapper;
    @Resource
    private UserMapper userMapper;

    /**
     * 新增
     */
    public void add(HotelReserve hotelReserve) {
        Hotel hotel = hotelMapper.selectById(hotelReserve.getHotelId());
        if (hotel.getNum() <= 0) {
            throw new CustomException("房间售罄，请选择其他房间");
        }
        User user = userMapper.selectById(hotelReserve.getUserId());
        if (user.getAccount() < hotel.getPrice() * hotelReserve.getNum()) {
            throw new CustomException("余额不足，请到个人中心充值");
        }
        user.setAccount(user.getAccount() - hotel.getPrice());
        userMapper.updateById(user);
        hotel.setNum(hotel.getNum() - hotelReserve.getNum());
        hotelMapper.updateById(hotel);
        hotelReserve.setPrice(hotel.getPrice() * hotelReserve.getNum());
        hotelReserveMapper.insert(hotelReserve);
    }

    /**
     * 删除
     */
    public void deleteById(Integer id) {
        hotelReserveMapper.deleteById(id);
    }

    /**
     * 修改
     */
    public void updateById(HotelReserve hotelReserve) {
        if ("已退房".equals(hotelReserve.getStatus())) {
            Hotel hotel = hotelMapper.selectById(hotelReserve.getHotelId());
            if (ObjectUtil.isNotEmpty(hotel)) {
                hotel.setNum(hotel.getNum() + hotelReserve.getNum());
                hotelMapper.updateById(hotel);
            }
        }
        hotelReserveMapper.updateById(hotelReserve);
    }

    /**
     * 根据ID查询
     */
    public HotelReserve selectById(Integer id) {
        return hotelReserveMapper.selectById(id);
    }

    /**
     * 查询所有
     */
    public List<HotelReserve> selectAll(HotelReserve hotelReserve) {
        return hotelReserveMapper.selectAll(hotelReserve);
    }

    /**
     * 分页查询
     */
    public PageInfo<HotelReserve> selectPage(HotelReserve hotelReserve, Integer pageNum, Integer pageSize) {
        PageHelper.startPage(pageNum, pageSize);
        List<HotelReserve> list = hotelReserveMapper.selectAll(hotelReserve);
        return PageInfo.of(list);
    }

}