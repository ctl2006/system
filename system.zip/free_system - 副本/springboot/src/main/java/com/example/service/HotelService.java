package com.example.service;

import com.example.entity.Hotel;
import com.example.mapper.HotelMapper;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import jakarta.annotation.Resource;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class HotelService {

    @Resource
    private HotelMapper hotelMapper;

    /**
     * 新增
     */
    public void add(Hotel hotel) {
        hotelMapper.insert(hotel);
    }

    /**
     * 删除
     */
    public void deleteById(Integer id) {
        hotelMapper.deleteById(id);
    }

    /**
     * 修改
     */
    public void updateById(Hotel hotel) {
        hotelMapper.updateById(hotel);
    }

    /**
     * 根据ID查询
     */
    public Hotel selectById(Integer id) {
        return hotelMapper.selectById(id);
    }

    /**
     * 查询所有
     */
    public List<Hotel> selectAll(Hotel hotel) {
        return hotelMapper.selectAll(hotel);
    }

    /**
     * 分页查询
     */
    public PageInfo<Hotel> selectPage(Hotel hotel, Integer pageNum, Integer pageSize) {
        PageHelper.startPage(pageNum, pageSize);
        List<Hotel> list = hotelMapper.selectAll(hotel);
        return PageInfo.of(list);
    }

}