package com.example.controller;

import com.example.common.Result;
import com.example.entity.Projects;
import com.example.service.ProjectsService;
import com.github.pagehelper.PageInfo;
import jakarta.annotation.Resource;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 体检前端操作接口
 **/
//Spring Boot 的魔法注解。它告诉框架：“这个类是一个控制器，它里面的方法都会返回数据给前端，不用去渲染网页页面。”
@RestController
//它设定了一个路由前缀。当前端请求的网址以 /projects 开头时，框架就会把这个请求交给这个控制器来处理。
@RequestMapping("/projects")
public class ProjectsController {

    @Resource
    private ProjectsService projectsService;

    /**
     * 新增
     */
    //规定前端必须用 POST 请求方式访问 /projects/add 这个网址。
    @PostMapping("/add")
    public Result add(@RequestBody Projects projects) {
        projectsService.add(projects);
        return Result.success();
    }

    /**
     * 删除
     */
    @DeleteMapping("/delete/{id}")
    public Result deleteById(@PathVariable Integer id) {
        projectsService.deleteById(id);
        return Result.success();
    }

    /**
     * 修改
     */
    @PutMapping("/update")
    public Result updateById(@RequestBody Projects projects) {
        projectsService.updateById(projects);
        return Result.success();
    }

    /**
     * 根据ID查询
     */
    @GetMapping("/selectById/{id}")
    public Result selectById(@PathVariable Integer id) {
        Projects projects = projectsService.selectById(id);
        return Result.success(projects);
    }

    /**
     * 查询所有
     */
    @GetMapping("/selectAll")
    public Result selectAll(Projects projects) {
        List<Projects> list = projectsService.selectAll(projects);
        return Result.success(list);
    }

    /**
     * 分页查询
     */
    @GetMapping("/selectPage")
    public Result selectPage(Projects projects,
                             @RequestParam(defaultValue = "1") Integer pageNum,
                             @RequestParam(defaultValue = "10") Integer pageSize) {
        PageInfo<Projects> page = projectsService.selectPage(projects, pageNum, pageSize);
        return Result.success(page);
    }

}