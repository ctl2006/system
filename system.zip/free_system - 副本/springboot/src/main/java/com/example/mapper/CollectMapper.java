package com.example.mapper;

import com.example.entity.Collect;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Select;

import java.util.List;

/**
 * 操作collect相关数据接口
*/
public interface CollectMapper {

    /**
      * 新增
    */
    void insert(Collect collect);

    /**
      * 删除
    */
    @Delete("delete from collect where id = #{id}")
    void deleteById(Integer id);

    /**
      * 修改
    */
    void updateById(Collect collect);

    /**
      * 根据ID查询
    */
    @Select("select * from collect where id = #{id}")
    Collect selectById(Integer id);

    /**
      * 查询所有
    */
    List<Collect> selectAll(Collect collect);


}