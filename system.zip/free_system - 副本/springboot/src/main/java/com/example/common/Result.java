package com.example.common;

public class Result {
    private String code;
    private String msg;
    private Object data;

    private Result(Object data) {
        this.data = data;
    }

    public Result() {
    }

    /**
     * 静态方法：成功，不带返回数据
     * 使用：Result.success()
     */
    public static Result success() {
        Result result = new Result();
        result.setCode("200");
        result.setMsg("请求成功");
        return result;
    }

    /**
     * 静态重载方法：成功，并且要返回数据给前端
     * 使用：Result.success(adminList)
     */
    public static Result success(Object data) {
        Result result = success();
        result.setData(data);
        return result;
    }

    /**
     * 静态方法：失败，使用默认提示“请求失败”
     * 使用：Result.error()
     */
    public static Result error() {
        Result result = new Result();
        result.setCode("500");
        result.setMsg("请求失败");
        return result;
    }

    /**
     * 静态重载方法：失败，可以自己写错误提示文字
     * 使用：Result.error("用户名密码错误")
     */
    public static Result error(String msg) {
        Result result = new Result();
        result.setCode("500");
        result.setMsg(msg);
        return result;
    }

    // get：获取code的值
    public String getCode() {
        return code;
    }

    // set：设置code的值
    public void setCode(String code) {
        this.code = code;
    }

    // get：获取msg的值
    public String getMsg() {
        return msg;
    }

    // set：设置msg的值
    public void setMsg(String msg) {
        this.msg = msg;
    }

    // get：获取data的值
    public Object getData() {
        return data;
    }

    // set：设置data的值
    public void setData(Object data) {
        this.data = data;
    }
}
