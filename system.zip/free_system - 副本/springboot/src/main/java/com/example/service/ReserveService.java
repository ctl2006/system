package com.example.service;

import cn.hutool.core.date.DateUtil;
import com.example.entity.Projects;
import com.example.entity.Reserve;
import com.example.entity.User;
import com.example.exception.CustomException;
import com.example.mapper.ProjectsMapper;
import com.example.mapper.ReserveMapper;
import com.example.mapper.UserMapper;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import jakarta.annotation.Resource;
import org.springframework.stereotype.Service;

import java.util.List;

/**

 * 预约业务处理
 **/
@Service
public class ReserveService {

    @Resource
    private ReserveMapper reserveMapper;
    @Resource
    private ProjectsMapper projectsMapper;
    @Resource
    private UserMapper userMapper;

    /**
     * 新增
     */
    public void add(Reserve reserve) {
        Projects projects = projectsMapper.selectById(reserve.getProjectsId());
        User user = userMapper.selectById(reserve.getUserId());
        if (user.getAccount() < projects.getPrice()) {
            throw new CustomException("余额不足，请到个人中心充值");
        }
        user.setAccount(user.getAccount() - projects.getPrice());
        userMapper.updateById(user);
        reserveMapper.insert(reserve);
    }

    /**
     * 删除
     */
    public void deleteById(Integer id) {
        reserveMapper.deleteById(id);
    }

    /**
     * 修改
     */
    public void updateById(Reserve reserve) {
        reserveMapper.updateById(reserve);
    }

    /**
     * 根据ID查询
     */
    public Reserve selectById(Integer id) {
        return reserveMapper.selectById(id);
    }

    /**
     * 查询所有
     */
    public List<Reserve> selectAll(Reserve reserve) {
        return reserveMapper.selectAll(reserve);
    }

    /**
     * 分页查询
     */
    public PageInfo<Reserve> selectPage(Reserve reserve, Integer pageNum, Integer pageSize) {
        PageHelper.startPage(pageNum, pageSize);
        List<Reserve> list = reserveMapper.selectAll(reserve);
        return PageInfo.of(list);
    }

}