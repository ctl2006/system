/** @type {import('tailwindcss').Config} */
export default {
    // 扫描所有vue、js文件
    content: ["./index.html", "./src/**/*.{vue,js,ts,jsx,tsx}"],
    theme: {
        extend: {},
    },
    plugins: [],
}
