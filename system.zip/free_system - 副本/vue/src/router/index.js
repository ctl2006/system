import {createRouter, createWebHistory} from 'vue-router'

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    { path: '/', redirect: '/login' },
    {
      path: '/manager',
      component: () => import('@/views/Manager.vue'),
      redirect: '/manager/home',
      children: [
          { path: 'person', component: () => import('@/views/manager/Person.vue')},
          { path: 'password', component: () => import('@/views/manager/Password.vue')},
          { path: 'home', component: () => import('@/views/manager/Home.vue')},
          { path: 'admin', component: () => import('@/views/manager/Admin.vue')},
          { path: 'user', component: () => import('@/views/manager/User.vue')},
          { path: 'teacher', component: () => import('@/views/manager/Teacher.vue')},
          { path: 'book', component: () => import('@/views/manager/Book.vue')},
          { path: 'borrow', component: () => import('@/views/manager/Borrow.vue')},
          { path: 'article', component: () => import('@/views/manager/Article.vue')},
          { path: 'praise', component: () => import('@/views/manager/Praise.vue')},
          { path: 'collect', component: () => import('@/views/manager/Collect.vue')},
          { path: 'comments', component: () => import('@/views/manager/Comments.vue')},
          { path: 'orders', component: () => import('@/views/manager/Orders.vue')},
          { path: 'chapter', component: () => import('@/views/manager/Chapter.vue')},
          { path: 'bookContent', component: () => import('@/views/manager/BookContent.vue')},
          { path: 'dashboard', component: () => import('@/views/manager/Dashboard.vue')},
          { path: 'projects', component: () => import('@/views/manager/Projects.vue')},
          { path: 'reserve', component: () => import('@/views/manager/Reserve.vue')},
          { path: 'hotel', component: () => import('@/views/manager/Hotel.vue')},
          { path: 'hotelReserve', component: () => import('@/views/manager/HotelReserve.vue')},
          { path: 'chat', component: () => import('@/views/manager/Chat.vue')},
          { path: 'homework', component: () => import('@/views/manager/Homework.vue')},
          { path: 'submit', component: () => import('@/views/manager/Submit.vue')},

      ]
    },
    {
      path: '/front',
      component: () => import('@/views/Front.vue'),
      children: [
          { path: 'home', component: () => import('@/views/front/Home.vue'),  },
          { path: 'person', component: () => import('@/views/front/Person.vue'),  },
          { path: 'password', component: () => import('@/views/front/Password.vue'),  },
          { path: 'layout', component: () => import('@/views/front/Layout.vue'),  },
          { path: 'book', component: () => import('@/views/front/Book.vue'),  },
          { path: 'myArticle', component: () => import('@/views/front/MyArticle.vue'),  },
          { path: 'article', component: () => import('@/views/front/Article.vue'),  },
          { path: 'articleDetail', component: () => import('@/views/front/ArticleDetail.vue'),  },
          { path: 'myComments', component: () => import('@/views/front/MyComments.vue'),  },
          { path: 'myOrders', component: () => import('@/views/front/MyOrders.vue'),  },
          { path: 'ContentDetail', component: () => import('@/views/front/ContentDetail.vue'),  },
          { path: 'friendApply', component: () => import('@/views/front/FriendApply.vue'),  },
          { path: 'myFriends', component: () => import('@/views/front/MyFriends.vue'),  },
          { path: 'myReserve', component: () => import('@/views/front/MyReserve.vue'),  },
          { path: 'projects', component: () => import('@/views/front/Projects.vue')},
          { path: 'hotel', component: () => import('@/views/front/Hotel.vue')},
          { path: 'myHotel', component: () => import('@/views/front/MyHotel.vue')},
          { path: 'myChat', component: () => import('@/views/front/MyChat.vue')},
          { path: 'homework', component: () => import('@/views/front/Homework.vue')},
          { path: 'mySubmit', component: () => import('@/views/front/MySubmit.vue')},


      ]
    },
    { path: '/login', component: () => import('@/views/Login.vue')},
    { path: '/register', component: () => import('@/views/Register.vue')},
  ]
})

export default router
