<template>
  <div>
<!--    <div class="front-notice"><el-icon><Bell /></el-icon>公告：{{ data.top }}</div>-->
    <div class="front-header">
      <div class="front-header-left">
        <img src="@/assets/imgs/logo.png" alt="">
        <div class="title">项目前台</div>
      </div>
      <div class="front-header-center">
        <el-menu :default-active="router.currentRoute.value.path" router mode="horizontal">
          <el-menu-item index="/front/home">首页</el-menu-item>
          <el-menu-item index="/front/layout">页面布局</el-menu-item>
          <el-menu-item index="/front/book">热门图书</el-menu-item>
          <el-menu-item index="/front/article">交流论坛</el-menu-item>
          <el-menu-item index="/front/projects">体检预约</el-menu-item>
          <el-menu-item index="/front/hotel">酒店预约</el-menu-item>
          <el-menu-item index="/front/homework">作业提交</el-menu-item>
        </el-menu>
      </div>
      <div class="front-header-right">
        <div v-if="!data.user.id">
          <el-button @click="router.push('/login')">登录</el-button>
          <el-button @click="router.push('/register')">注册</el-button>
        </div>
        <div v-else>
          <el-dropdown style="cursor: pointer; height: 60px">
            <div style="display: flex; align-items: center">
              <img style="width: 40px; height: 40px; border-radius: 50%;" :src="data.user.avatar" alt="">
              <span style="margin-left: 5px;">{{ data.user.name }}</span><el-icon><arrow-down /></el-icon>
            </div>
            <template #dropdown>
              <el-dropdown-menu>
                <el-dropdown-item @click="router.push('/front/myFriends')">我的好友</el-dropdown-item>
                <el-dropdown-item @click="router.push('/front/friendApply')">好友申请</el-dropdown-item>
                <el-dropdown-item @click="router.push('/front/myOrders')">我的订单</el-dropdown-item>
                <el-dropdown-item @click="router.push('/front/myReserve')">我的体检</el-dropdown-item>
                <el-dropdown-item @click="router.push('/front/myComments')">我的评论</el-dropdown-item>
                <el-dropdown-item @click="router.push('/front/myChat')">我的说说</el-dropdown-item>
                <el-dropdown-item @click="router.push('/front/myArticle')">我的帖子</el-dropdown-item>
                <el-dropdown-item @click="router.push('/front/myHotel')">我的入住</el-dropdown-item>
                <el-dropdown-item @click="router.push('/front/mySubmit')">我的作业</el-dropdown-item>
                <el-dropdown-item @click="router.push('/front/person')">个人中心</el-dropdown-item>
                <el-dropdown-item @click="router.push('/front/password')">修改密码</el-dropdown-item>
                <el-dropdown-item @click="logout">退出登录</el-dropdown-item>
              </el-dropdown-menu>
            </template>
          </el-dropdown>
        </div>
      </div>
    </div>
    <div class="main-body">
      <RouterView @updateUser="updateUser" />
    </div>
  </div>
</template>

<script setup>
  import router from "@/router/index.js";
  import { reactive } from "vue";
  import request from "@/utils/request.js";

  const data = reactive({
    user: JSON.parse(localStorage.getItem('system-user') || '{}'),
    top: '',
    noticeData: []
  })

  const logout = () => {
    localStorage.removeItem('system-user')
    router.push('/login')
  }

  const updateUser = () => {
    data.user =  JSON.parse(localStorage.getItem('system-user') || '{}')
  }

  // const loadNotice = () => {
  //   request.get('/notice/selectAll').then(res => {
  //     data.noticeData = res.data
  //     let i = 0
  //     if (data.noticeData && data.noticeData.length) {
  //       data.top = data.noticeData[0].content
  //       setInterval(() => {
  //         data.top = data.noticeData[i].content
  //         i++
  //         if (i === data.noticeData.length) {
  //           i = 0
  //         }
  //       }, 2500)
  //     }
  //   })
  // }
  // loadNotice()
</script>

<style scoped>
@import "@/assets/css/front.css";
</style>