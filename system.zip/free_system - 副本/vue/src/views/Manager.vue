<template>
  <div>
    <div style="height: 60px; background-color: #fff; display: flex; align-items: center; border-bottom: 1px solid #ddd">
      <div style="flex: 1">
        <div style="padding-left: 20px; display: flex; align-items: center">
          <img src="@/assets/imgs/logo.png" alt="" style="width: 40px">
          <div style="font-weight: bold; font-size: 24px; margin-left: 5px">管理系统</div>
        </div>
      </div>
      <div style="width: fit-content; padding-right: 10px; display: flex; align-items: center;">
        <img style="width: 40px; height: 40px; border-radius: 50%" :src="data.user.avatar || 'https://cube.elemecdn.com/3/7c/3ea6beec64369c2642b92c6726f1epng.png'" alt="">
        <span style="margin-left: 5px">{{ data.user.name }}</span>
      </div>
    </div>

    <div style="display: flex">
      <div style="width: 200px; border-right: 1px solid #ddd; min-height: calc(100vh - 60px)">
        <el-menu
            router
            style="border: none"
            :default-active="router.currentRoute.value.path"
            :default-openeds="['user']"
        >
          <el-menu-item index="/manager/home">
            <el-icon><HomeFilled /></el-icon>
            <span>系统首页</span>
          </el-menu-item>
          <el-menu-item index="/manager/dashboard">
            <el-icon><DataLine /></el-icon>
            <span>数据统计</span>
          </el-menu-item>
          <el-sub-menu index="info">
            <template #title>
              <el-icon><Position /></el-icon>
              <span>信息管理</span>
            </template>
            <el-menu-item index="/manager/book">
              <el-icon><Notebook /></el-icon>
              <span>图书信息</span>
            </el-menu-item>
            <el-menu-item index="/manager/chapter">
              <el-icon><Notebook /></el-icon>
              <span>章节信息</span>
            </el-menu-item>
            <el-menu-item index="/manager/bookContent">
              <el-icon><Notebook /></el-icon>
              <span>图书内容</span>
            </el-menu-item>
            <el-menu-item index="/manager/borrow">
              <el-icon><Clock /></el-icon>
              <span>借阅记录</span>
            </el-menu-item>
            <el-menu-item index="/manager/article">
              <el-icon><Document /></el-icon>
              <span>帖子信息</span>
            </el-menu-item>
            <el-menu-item index="/manager/praise">
              <el-icon><Pointer /></el-icon>
              <span>点赞信息</span>
            </el-menu-item>
            <el-menu-item index="/manager/collect">
              <el-icon><Star /></el-icon>
              <span>收藏信息</span>
            </el-menu-item>
            <el-menu-item index="/manager/comments">
              <el-icon><ChatSquare /></el-icon>
              <span>评论信息</span>
            </el-menu-item>
            <el-menu-item index="/manager/orders">
              <el-icon><ChatSquare /></el-icon>
              <span>订单信息</span>
            </el-menu-item>
            <el-menu-item index="/manager/projects">
              <el-icon><FirstAidKit /></el-icon>
              <span>体检项目</span>
            </el-menu-item>
            <el-menu-item index="/manager/reserve">
              <el-icon><Checked /></el-icon>
              <span>体检预约</span>
            </el-menu-item>
            <el-menu-item index="/manager/hotel">
              <el-icon><OfficeBuilding /></el-icon>
              <span>酒店信息</span>
            </el-menu-item>
            <el-menu-item index="/manager/hotelReserve">
              <el-icon><Checked /></el-icon>
              <span>酒店预订</span>
            </el-menu-item>
            <el-menu-item index="/manager/chat">
              <el-icon><ChatLineSquare /></el-icon>
              <span>用户说说</span>
            </el-menu-item>
            <el-menu-item index="/manager/homework">
              <el-icon><EditPen /></el-icon>
              <span>作业信息</span>
            </el-menu-item>
            <el-menu-item index="/manager/submit">
              <el-icon><EditPen /></el-icon>
              <span>作业批改</span>
            </el-menu-item>
          </el-sub-menu>
          <el-sub-menu index="user">
            <template #title>
              <el-icon><Memo /></el-icon>
              <span>用户管理</span>
            </template>
            <el-menu-item index="/manager/admin">
              <el-icon><User /></el-icon>
              <span>管理员信息</span>
            </el-menu-item>
            <el-menu-item index="/manager/user">
              <el-icon><User /></el-icon>
              <span>用户信息</span>
            </el-menu-item>
            <el-menu-item index="/manager/teacher">
              <el-icon><User /></el-icon>
              <span>教师信息</span>
            </el-menu-item>
          </el-sub-menu>
          <el-menu-item index="/manager/person">
            <el-icon><User /></el-icon>
            <span>个人资料</span>
          </el-menu-item>
          <el-menu-item index="/manager/password">
            <el-icon><Lock /></el-icon>
            <span>修改密码</span>
          </el-menu-item>
          <el-menu-item index="/login" @click="logout">
            <el-icon><SwitchButton /></el-icon>
            <span>退出系统</span>
          </el-menu-item>
        </el-menu>
      </div>

      <div style="flex: 1; width: 0; background-color: #f8f8ff; padding: 10px">
        <router-view @updateUser="updateUser" />
      </div>
    </div>

  </div>
</template>

<script setup>
import { reactive } from "vue";
import router from "@/router";
import {ElMessage} from "element-plus";

const data = reactive({
  user: JSON.parse(localStorage.getItem('system-user') || '{}')
})

if (!data.user?.id) {
  ElMessage.error('请登录！')
  router.push('/login')
}

const updateUser = () => {
  data.user = JSON.parse(localStorage.getItem('system-user') || '{}')
}

const logout = () => {
  ElMessage.success('退出成功')
  localStorage.removeItem('system-user')
  router.push('/login')
}
</script>

<style scoped>
.el-menu-item.is-active {
  background-color: #e0edfd !important;
}
.el-menu-item:hover {
  color: #1967e3;
}
:deep(th)  {
  color: #333;
}
</style>