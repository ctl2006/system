<template>
  <div>
    <div class="card h-[400px]" id="line"></div>
    <div class="mt-[10px] flex gap-[10px]">
      <div class="card flex-1 h-[400px]" id="bar"></div>
      <div class="card flex-1 h-[400px]" id="pie"></div>
    </div>

  </div>
</template>

<script setup>
import { reactive, onMounted, nextTick } from "vue";
import request from "@/utils/request";
import * as echarts from "echarts";

const data = reactive({
  user: JSON.parse(localStorage.getItem('system-user') || '{}'),
})

const loadLine = () => {
  request.get('dashboard/line').then(res => {
    if (res.code === '200') {
      let chartDom = document.getElementById('line');
      let myChart = echarts.init(chartDom);
      lineOptions.xAxis.data = res.data.x
      lineOptions.series[0].data = res.data.y
      myChart.setOption(lineOptions);
    }
  })
}
const loadBar = () => {
  request.get('dashboard/bar').then(res => {
    if (res.code === '200') {
      let chartDom = document.getElementById('bar');
      let myChart = echarts.init(chartDom);
      barOptions.xAxis.data = res.data.x
      barOptions.series[0].data = res.data.y
      myChart.setOption(barOptions);
    }
  })
}
const loadPie = () => {
  request.get('dashboard/pie').then(res => {
    if (res.code === '200') {
      let chartDom = document.getElementById('pie');
      let myChart = echarts.init(chartDom);
      pieOptions.series[0].data = res.data
      myChart.setOption(pieOptions);
    }
  })
}

onMounted(() => {
    loadLine()
    loadBar()
    loadPie()
})

// console.log(echarts.version)

// 平滑折线图
let lineOptions = {
  title: {
    text: '近一个月用户发布帖子折线图',
    subtext: '统计维度：最近一月',
    left: 'center'
  },
  legend: {
    data: [],
    template:""
  },
  grid: {
    left: '3%',
    right: '4%',
    bottom: '3%',
    top: '20%',
    containLabel: true
  },
  tooltip: {
    trigger: 'item'
  },
  xAxis: {
    name: '日期',
    type: 'category',
    data: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']
  },
  yAxis: {
    name: '帖子数量',
    type: 'value'
  },
  series: [
    {
      name: '帖子数量',
      data: [100, 932, 901, 934, 1290, 1330, 1320],
      type: 'line',
      smooth: true,
      markLine: {
        data: [{ type: 'average', name: '系统中近一个月发布帖子数量平均值' }]
      },
      markPoint: {
        data: [
          { type: 'max', name: '最大值' },
          { type: 'min', name: '最小值' }
        ]
      },
    },
  ]
}
// 饼图
let pieOptions = {
  title: {
    text: '不同出版社图书数量占比', // 主标题
    subtext: '统计维度：出版社', // 副标题
    left: 'center'
  },
  tooltip: {
    trigger: 'item',
    formatter: '{a} <br/>{b} : {c} ({d}%)'
  },
  legend: {
    orient: 'vertical',
    left: 'left'
  },
  series: [
    {
      name: '数量占比', // 鼠标移上去显示内容
      type: 'pie',
      radius: '50%',
      center: ['50%', '60%'],
      data: [
        {value: 1, name: '轻微'}, // 示例数据：name表示维度，value表示对应的值
        {value: 735, name: '雀巢咖啡'},
        {value: 580, name: '星巴克咖啡'},
        {value: 484, name: '栖巢咖啡'},
        {value: 300, name: '小武哥咖啡'}
      ]
    }
  ]
}
// 柱状图
let barOptions = {
  title: {
    text: '系统中不同书本借阅数量统计（柱状图）', // 主标题
    subtext: '统计维度：书本名称', // 副标题
    left: 'center'
  },
  grid : {   // ---------------------------增加这个属性，bottom就是距离底部的距离
    bottom : '10%',
    top: '25%'
  },
  legend: {
    orient: 'vertical',
    left: 'left'
  },
  xAxis: {
    type: 'category',
    data: ['哈哈哈', '嘿嘿嘿', '呵呵呵', 'Thu', 'Fri', 'Sat', 'Sun'], // 示例数据：统计的维度（横坐标）
    name: '书本名称',
    axisLabel: {
      show: true, // 是否显示刻度标签，默认显示
      interval: 0, // 坐标轴刻度标签的显示间隔，在类目轴中有效；默认会采用标签不重叠的策略间隔显示标签；可以设置成0强制显示所有标签；如果设置为1，表示『隔一个标签显示一个标签』，如果值为2，表示隔两个标签显示一个标签，以此类推。
      rotate: -60, // 刻度标签旋转的角度，在类目轴的类目标签显示不下的时候可以通过旋转防止标签之间重叠；旋转的角度从-90度到90度
      inside: false, // 刻度标签是否朝内，默认朝外
      margin: 6, // 刻度标签与轴线之间的距离
    },
  },
  yAxis: {
    type: 'value',
    name: '借阅数量',
  },
  tooltip: {
    trigger: 'item',
  },
  series: [
    {
      data: [120, 250, 150, 80, 70, 110, 130], // 示例数据：横坐标维度对应的值（纵坐标）
      type: 'bar',
      itemStyle: {
        normal: {
          color: function () {
            return "#" + Math.floor(Math.random() * (256 * 256 * 256 - 1)).toString(16);
          }
        },
      },
    }
  ]
}
</script>