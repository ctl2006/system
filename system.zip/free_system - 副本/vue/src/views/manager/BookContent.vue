<!--教师信息页面-->
<template>
  <div>

<!--搜索框-->
    <div class="card" style="margin-bottom: 5px;">
      <el-input v-model="data.bookName" style="width: 300px; margin-right: 10px" placeholder="请输入图书名称查询"></el-input>
      <el-input v-model="data.chapterName" style="width: 300px; margin-right: 10px" placeholder="请输入章节名称查询"></el-input>
      <el-button type="primary" @click="load">查询</el-button>
      <el-button type="info" style="margin: 0 10px" @click="reset">重置</el-button>
    </div>
<!--列表卡片-->
    <div class="card" style="margin-bottom: 5px">
      <div style="margin-bottom: 10px">
        <el-button type="primary" @click="handleAdd">新增</el-button>
      </div>

      <el-table :data="data.tableData" stripe tooltip-effect="dark myEffect">
        <el-table-column label="图书名称" prop="bookName" show-overflow-tooltip></el-table-column>
        <el-table-column label="章节名称" prop="chapterName" show-overflow-tooltip></el-table-column>
        <el-table-column label="图书内容" align="center" prop="content">
          <template v-slot="scope">
            <el-button type="info" @click="viewInit(scope.row.content)">点击查看</el-button>
          </template>
        </el-table-column>
        <el-table-column label="操作" align="center" width="160">
          <template #default="scope">
            <el-button type="primary" @click="handleEdit(scope.row)">编辑</el-button>
            <el-button type="danger" @click="handleDelete(scope.row.id)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
    </div>
<!--分页-->
    <div class="card">
      <el-pagination style="display: flex;justify-content: center" @current-change="load" background layout="prev, pager, next" v-model:page-size="data.pageSize" v-model:current-page="data.pageNum" :total="data.total"/>
    </div>

    <el-dialog title="图书信息" width="50%" v-model="data.formVisible" :close-on-click-modal="false" destroy-on-close>
      <el-form :model="data.form" label-width="100px" style="padding-right: 50px">
        <el-form-item label="图书名称" prop="bookId">
          <el-select v-model="data.form.bookId" placeholder="请选择图书" @change="loadChapter(data.form.bookId)">
            <el-option
                v-for="item in data.bookData"
                :label="item.name"
                :value="item.id"
                :key="item.id"
            />
          </el-select>
        </el-form-item>
        <el-form-item label="章节名称" prop="chapterId">
          <el-select v-model="data.form.chapterId" placeholder="请选择章节">
            <el-option
                v-for="item in data.chapterData"
                :label="item.name"
                :value="item.id"
                :key="item.id"
            />
          </el-select>
        </el-form-item>
        <el-form-item prop="content" label="图书内容">
          <div style="border: 1px solid #ccc; width: 100%">
            <Toolbar
                style="border-bottom: 1px solid #ccc"
                :editor="editorRef"
                :mode="mode"
            />
            <Editor
                style="height: 500px; overflow-y: hidden;"
                v-model="data.form.content"
                :mode="mode"
                :defaultConfig="editorConfig"
                @onCreated="handleCreated"
            />
          </div>
        </el-form-item>
      </el-form>
      <template #footer>
      <span class="dialog-footer">
        <el-button @click="data.formVisible = false">取 消</el-button>
        <el-button type="primary" @click="save">保 存</el-button>
      </span>
      </template>
    </el-dialog>
  </div>

  <!--查看内容-->
  <el-dialog title="帖子信息" width="50%" v-model="data.viewVisible" :close-on-click-modal="false" destroy-on-close>
    <div v-html="data.viewContent"></div>
  </el-dialog>

</template>

<script setup>
import request from "@/utils/request";
import {onBeforeUnmount, reactive, ref, shallowRef} from "vue";
import {ElMessageBox, ElMessage} from "element-plus";
import '@wangeditor/editor/dist/css/style.css'
import { Editor, Toolbar } from '@wangeditor/editor-for-vue'
import '@wangeditor/editor/dist/css/style.css' // 引入 css

// 文件上传的接口地址
const uploadUrl = import.meta.env.VITE_BASE_URL + '/files/upload'
const wangUploadUrl = import.meta.env.VITE_BASE_URL + '/files/wang/upload'

const data = reactive({
  user: JSON.parse(localStorage.getItem('system-user') || '{}'),
  pageNum: 1,
  pageSize: 5,
  total: 0,
  formVisible: false,
  form: {},
  bookData: [],
  tableData: [],
  chapterData: [],
  bookName: null,
  chapterName: null,
  viewContent: null,
  viewVisible: false
})

// 点击查看
const viewInit = (content) => {
  data.viewContent = content
  data.viewVisible = true
}

/* wangEditor5 初始化开始 */
const editorRef = shallowRef()  // 编辑器实例，必须用 shallowRef
const mode = 'default'
const editorConfig = { MENU_CONF: {} }
// 图片上传配置
editorConfig.MENU_CONF['uploadImage'] = {
  headers: {
    token: data.user.token,
  },
  server: wangUploadUrl,  // 服务端图片上传接口
  fieldName: 'file'  // 服务端图片上传接口参数
}
// 组件销毁时，也及时销毁编辑器，否则可能会造成内存泄漏
onBeforeUnmount(() => {
  const editor = editorRef.value
  if (editor == null) return
  editor.destroy()
})
// 记录 editor 实例，重要！
const handleCreated = (editor) => {
  editorRef.value = editor
}
/* wangEditor5 初始化结束 */

const loadBook = () => {
  request.get('/book/selectAll').then(res => {
    if (res.code === '200'){
      data.bookData = res.data
    }
    else {
      ElMessage.error(res.msg)
    }
  })
}
loadBook()
const loadChapter = (bookId) => {
  data.form.chapterId = null
  request.get('/chapter/selectAll',{
    params: {
      bookId: bookId
    }
  }).then(res => {
    if (res.code === '200'){
      data.chapterData = res.data
    }
    else {
      ElMessage.error(res.msg)
    }
  })
}

// 分页查询
const load = () => {
  request.get('/bookContent/selectPage', {
    params: {
      pageNum: data.pageNum,
      pageSize: data.pageSize,
      chapterName: data.chapterName,
      bookName: data.bookName
    }
  }).then(res => {
    data.tableData = res.data?.list
    data.total = res.data?.total
  })
}

// 新增
const handleAdd = () => {
  data.form = {}
  data.formVisible = true
  data.chapterData = []
}

// 编辑
const handleEdit = (row) => {
  data.form = JSON.parse(JSON.stringify(row))
  data.formVisible = true
}

// 新增保存
const add = () => {
  request.post('/bookContent/add', data.form).then(res => {
    if (res.code === '200') {
      load()
      ElMessage.success('操作成功')
      data.formVisible = false
    } else {
      ElMessage.error(res.msg)
    }
  })
}

// 编辑保存
const update = () => {
  request.put('/bookContent/update', data.form).then(res => {
    if (res.code === '200') {
      load()
      ElMessage.success('操作成功')
      data.formVisible = false
    } else {
      ElMessage.error(res.msg)
    }
  })
}

// 弹窗保存
const save = () => {
  // data.form有id就是更新，没有就是新增
  data.form.id ? update() : add()
}

// 删除
const handleDelete = (id) => {
  ElMessageBox.confirm('删除后数据无法恢复，您确定删除吗?', '删除确认', { type: 'warning' }).then(res => {
    request.delete('/bookContent/delete/' + id).then(res => {
      if (res.code === '200') {
        load()
        ElMessage.success('操作成功')
      } else {
        ElMessage.error(res.msg)
      }
    })
  }).catch(err => {})
}

// 重置
const reset = () => {
  data.bookName = null
  data.chapterName = null
  load()
}


load()
</script>

<style>
.myEffect {
  max-width: 30%;
}
</style>