<!--信息页面-->
<template>
  <div>

<!--搜索框-->
    <div class="card" style="margin-bottom: 5px;">
      <el-input v-model="data.bookName" style="width: 300px; margin-right: 10px" placeholder="请输入项目名称查询"></el-input>
      <el-button type="primary" @click="load">查询</el-button>
      <el-button type="info" style="margin: 0 10px" @click="reset">重置</el-button>
    </div>
<!--列表卡片-->
    <div class="card" style="margin-bottom: 5px">
      <el-table :data="data.tableData" stripe>
        <el-table-column label="项目名称" prop="projectsName"></el-table-column>
        <el-table-column label="项目单价" prop="projectsPrice"></el-table-column>
        <el-table-column label="预约用户" prop="userName"></el-table-column>
        <el-table-column label="预约时间" prop="time"></el-table-column>
        <el-table-column label="预约状态" align="center" prop="status">
          <template #default="scope">
            <el-tag type="warning" v-if="scope.row.status==='待体检'">{{scope.row.status}}</el-tag>
            <el-tag type="success" v-if="scope.row.status==='已体检'">{{scope.row.status}}</el-tag>
          </template>
        </el-table-column>
        <el-table-column label="操作" align="center" width="160">
          <template #default="scope">
            <el-button type="primary" @click="checkIn(scope.row)">报到</el-button>
            <el-button type="danger" @click="handleDelete(scope.row.id)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
    </div>
<!--分页-->
    <div class="card">
      <el-pagination style="display: flex;justify-content: center" @current-change="load" background layout="prev, pager, next" v-model:page-size="data.pageSize" v-model:current-page="data.pageNum" :total="data.total"/>
    </div>

  </div>
</template>

<script setup>
import request from "@/utils/request";
import {reactive} from "vue";
import {ElMessageBox, ElMessage} from "element-plus";

// 文件上传的接口地址
const uploadUrl = import.meta.env.VITE_BASE_URL + '/files/upload'

const data = reactive({
  pageNum: 1,
  pageSize: 5,
  total: 0,
  form: {},
  tableData: [],
  projectsName: null
})

// 分页查询
const load = () => {
  request.get('/reserve/selectPage', {
    params: {
      pageNum: data.pageNum,
      pageSize: data.pageSize,
      projectsName: data.projectsName
    }
  }).then(res => {
    data.tableData = res.data?.list
    data.total = res.data?.total
  })
}

// 报到
const checkIn = (row) => {
  let data = JSON.parse(JSON.stringify(row))
  data.status = '已体检'
  request.put('/reserve/update', data).then(res => {
    if (res.code === '200') {
      ElMessage.success('操作成功')
      load()
    }
    else {
      ElMessage.error(res.msg)
    }
  })
}

// 删除
const handleDelete = (id) => {
  ElMessageBox.confirm('删除后数据无法恢复，您确定删除吗?', '删除确认', { type: 'warning' }).then(res => {
    request.delete('/reserve/delete/' + id).then(res => {
      if (res.code === '200') {
        load()
        ElMessage.success('操作成功')
      } else {
        ElMessage.error(res.msg)
      }
    })
  }).catch(err => {})
}

// 重置
const reset = () => {
  data.bookName = null
  load()
}

load()
</script>