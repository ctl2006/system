<!--信息页面-->
<template>
  <div>

<!--搜索框-->
    <div class="card" style="margin-bottom: 5px;">
      <el-input v-model="data.bookName" style="width: 300px; margin-right: 10px" placeholder="请输入图书名称查询"></el-input>
      <el-button type="primary" @click="load">查询</el-button>
      <el-button type="info" style="margin: 0 10px" @click="reset">重置</el-button>
    </div>
<!--列表卡片-->
    <div class="card" style="margin-bottom: 5px">
      <el-table :data="data.tableData" stripe>
        <el-table-column label="图书名称" prop="bookName"></el-table-column>
        <el-table-column label="借阅用户" prop="userName"></el-table-column>
        <el-table-column label="借阅时间" prop="time"></el-table-column>
        <el-table-column label="借阅状态" prop="status">
          <template #default="scope">
            <el-tag v-if="scope.row.status === '借阅中'" type="primary">借阅中</el-tag>
            <el-tag v-else type="success">已归还</el-tag>
          </template>
        </el-table-column>
        <el-table-column label="操作" align="center" width="160">
          <template #default="scope">
            <el-button type="primary" @click="returns(scope.row)">归还</el-button>
            <el-button type="danger" @click="handleDelete(scope.row.id)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
    </div>
<!--分页-->
    <div class="card">
      <el-pagination style="display: flex;justify-content: center" @current-change="load" background layout="prev, pager, next" v-model:page-size="data.pageSize" v-model:current-page="data.pageNum" :total="data.total"/>
    </div>

  </div>
</template>

<script setup>
import request from "@/utils/request";
import {reactive} from "vue";
import {ElMessageBox, ElMessage} from "element-plus";

// 文件上传的接口地址
const uploadUrl = import.meta.env.VITE_BASE_URL + '/files/upload'

const data = reactive({
  pageNum: 1,
  pageSize: 5,
  total: 0,
  form: {},
  tableData: [],
  bookName: null
})

// 分页查询
const load = () => {
  request.get('/borrow/selectPage', {
    params: {
      pageNum: data.pageNum,
      pageSize: data.pageSize,
      bookName: data.bookName
    }
  }).then(res => {
    data.tableData = res.data?.list
    data.total = res.data?.total
  })
}

// 归还
const returns = (row) => {
  let data = JSON.parse(JSON.stringify(row))
  data.status = '已归还'
  request.put('/borrow/update', data).then(res => {
    if (res.code === '200') {
      ElMessage.success('操作成功')
      load()
    }
    else {
      ElMessage.error(res.msg)
    }
  })
}

// 删除
const handleDelete = (id) => {
  ElMessageBox.confirm('删除后数据无法恢复，您确定删除吗?', '删除确认', { type: 'warning' }).then(res => {
    request.delete('/borrow/delete/' + id).then(res => {
      if (res.code === '200') {
        load()
        ElMessage.success('操作成功')
      } else {
        ElMessage.error(res.msg)
      }
    })
  }).catch(err => {})
}

// 重置
const reset = () => {
  data.bookName = null
  load()
}

load()
</script>