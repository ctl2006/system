<template>
  <div>
    <div style="margin-top: 20px " class="mt-[20px] mx-auto w-[80%] ">
      <el-row :gutter="20">
        <el-col :span="6" v-for="item in data.bookData" :key="item.id" class="mb-[30px]">
          <div>
            <img :src="item.img" class="h-[200px] w-full rounded-[5px]">
            <div style="font-size: 16px;font-weight: bold">{{item.name}}</div>
            <div class="text-sm mb-3 flex">
              价格：<span style="color: red" class="font-bold">￥{{item.price}}</span>
              <span class="ml-auto">剩余 {{item.num}}间</span>
            </div>
            <div class="text-sm text-gray-500 mt-[5px]">{{item.content}}</div>
            <div class="text-center">
              <el-button type="primary" @click="reserveInit(item.id)":disabled="item.num === 0">预约</el-button>
            </div>
          </div>
        </el-col>
      </el-row>
    </div>
    <!--分页-->
    <div class="mt-[50px]">
      <el-pagination style="display: flex;justify-content: center" @current-change="loadHotel" background layout="total, prev, pager, next" v-model:page-size="data.pageSize" v-model:current-page="data.pageNum" :total="data.total"/>
    </div>
  </div>

  <el-dialog title="预约时间" width="40%" v-model="data.formVisible" :close-on-click-modal="false" destroy-on-close>
    <el-form :model="data.form" label-width="100px" style="padding-right: 50px">
      <el-form-item label="选择时间" prop="num">
        <el-date-picker
            v-model="data.form.time"
            type="datetime"
            placeholder="请选择时间"
            value-format="YYYY-MM-DD HH:mm:ss"
        />
      </el-form-item>
      <el-form-item label="预订/                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   数量" prop="num">
        <el-input-number v-model="data.form.num" :min="1" />
      </el-form-item>
    </el-form>
    <template #footer>
      <span class="dialog-footer">
        <el-button @click="data.formVisible = false">取 消</el-button>
        <el-button type="primary" @click="reserve">预 约</el-button>
      </span>
    </template>
  </el-dialog>


</template>
<script setup>
import {reactive} from "vue";
import {ElMessage} from "element-plus";
import request from "@/utils/request";
import router from "@/router";

const data = reactive({
    user: JSON.parse(localStorage.getItem('system-user') || '{}'),
    bookData: [],
    chapterData: [],
    pageNum: 1,
    pageSize: 8,
    total: 0,
    form: {},
    formVisible: false,
    readVisible: false
})

const loadHotel = () => {
    request.get("/hotel/selectPage",{
        params:{
            pageNum: data.pageNum,
            pageSize: data.pageSize
        }
    }).then(res => {
        if (res.code === '200') {
            data.bookData = res.data?.list
            data.total = res.data?.total
        }
        else {
          ElMessage.error(res.msg)
        }
    })
}
loadHotel()


const reserveInit = (id) => {
  data.form = {}
  data.form.hotelId = id
  data.form.userId = data.user.id
  data.form.status = '待入住'
  data.formVisible = true
}

const reserve = () => {
  request.post("/hotelReserve/add", data.form).then(res => {
    console.log(res)
    if (res.code === '200') {
      ElMessage.success("预约成功")
      data.formVisible = false
    }
    else {
      ElMessage.error(res.msg)
    }
  })
}



</script>