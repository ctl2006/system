<template>
  <div style="margin: 20px auto; width: 60%">

    <div class="card flex flex-col items-center">
      <div class="text-center font-bold text-[18px]">{{data.articleData.title}}</div>
      <div class="mt-[10px] mb-[50px] text-center text-gray-500 flex">
        <span class="mr-[30px]">作者：{{data.articleData.userName}}</span>
        <el-button type="success" size="small" class="mr-[30px] ml-[-20px]" v-if="data.articleData.userId !== data.user.id && !data.friendFlag" @click="addFriend">加好友</el-button>
        <span>浏览量：{{data.articleData.views}}</span>
        <span class="mx-[30px]">发布时间：{{data.articleData.time}}</span>
        <el-button type="danger" size="small" @click="praise" v-if="data.praiseFlag">取消点赞</el-button>
        <el-button type="primary" size="small" @click="praise" v-else>点赞</el-button>

        <el-button type="danger" size="small" @click="collect" v-if="data.collectFlag">取消收藏</el-button>
        <el-button type="primary" size="small" @click="collect" v-else>收藏</el-button>
      </div>
      <div v-html="data.articleData.content"></div>
    </div>
    <div class="card mt-[10px]">
      <div>请说说你的想法吧</div>
      <div class="mt-[10px]">
        <el-input v-model="data.content" :row="4" type="textarea" placeholder="请输入评论内容"  />
      </div>
      <div class="mt-[10px] text-right">
        <el-button type="primary" @click="comment(data.content)">评论</el-button>
      </div>
      <div class="mb-[20px]">看看大家都评论了什么({{data.commentsData.length}})</div>

    <!--父评论-->
      <div v-for="(item, index) in data.commentsData" :key="index">

        <div class="flex gap-[20px] mt-[10px]">

          <img :src="item.userAvatar" class="w-[50px] h-[50px] rounded-[50%]">

          <div>

            <div class="font-bold">{{item.userName}}</div>

            <div class="mt-[10px]">{{item.content}}</div>

            <div class="mt-[5px] text-gray-500 text-sm flex items-center">
              <span class="mr-[20px]">{{item.time}}</span>
              <el-button type="info" size="small" @click="replyInit(item.id)">回复</el-button>
            </div>

          <!--子评论-->
            <div class=" mt-[20px]">
              <div v-for="(it, index) in item.children" :key="index">
                <div class="flex gap-[20px] w-full mt-[10px]">
                  <img :src="it.userAvatar" class="w-[50px] h-[50px] rounded-[50%]">
                  <div>
                    <div><span class="font-bold">{{it.userName}}</span> 回复：</div>
                    <div class="mt-[10px]">{{it.content}}</div>
                    <div class="mt-[5px] text-gray-500 text-sm flex items-center">
                      <span class="mr-[20px]">{{it.time}}</span>
                      <el-button type="info" size="small" @click="replyInit(it.id)">回复</el-button>
                    </div>
                  </div>
                </div>
              </div>
            </div>

          </div>
        </div>
      </div>
    </div>
  </div>

  <el-dialog title="评论回复" width="40%" v-model="data.dialogVisible" :close-on-click-modal="false" destroy-on-close>
    <div class="mt-[10px]">
      <el-input v-model="data.replyContent" :row="4" type="textarea" placeholder="请输入评论内容"  />
    </div>
    <template #footer>
      <span class="dialog-footer">
        <el-button type="primary" @click="comment(data.replyContent)">保 存</el-button>
      </span>
    </template>
  </el-dialog>
</template>
<script setup>
import request from "@/utils/request";
import {reactive} from "vue";
import router from "@/router"; // 引入 css
import {ElMessage} from "element-plus";

const data = reactive({
  user: JSON.parse(localStorage.getItem('system-user') || '{}'),
  articleId: router.currentRoute.value.query.id,
  articleData: {},
  praiseFlag: false,
  collectFlag: false,
  content: '',
  replyContent:'',
  commentsData: [],
  dialogVisible: false,
  fid: 0,
  friendFlag: false
})

const checkFriend = () => {
  request.get('/friends/check', {
    params: {
      fromId: data.user.id,
      toId: data.articleData.userId
    }
  }).then(res => {
    if (res.code == 200) {
      data.friendFlag = !!res.data.length;
    }
    else {
      ElMessage.error(res.msg)
    }
  })
}


const loadArticle = () => {
  request.get('/article/selectById/' + data.articleId).then(res => {
    if (res.code == 200) {
      data.articleData = res.data
      data.articleData.views = data.articleData.views + 1
      request.put(`/article/update`, data.articleData)
      checkFriend()
    }
    else {
      ElMessage.error(res.msg)
    }
  })
}

loadArticle()

//点赞
const praise = () => {
  request.post('/praise/add', {
    userId: data.user.id,
    relId: data.articleId,
  }).then(res => {
    if (res.code == 200) {
      ElMessage.success('操作成功')
      loadPraise()
    }
    else {
      ElMessage.error(res.msg)
    }
  })
}

const loadPraise = () => {
  request.get('/praise/selectAll', {
    params: {
      userId: data.user.id,
      relId: data.articleId
    }
  }).then(res => {
    if (res.code == 200) {
      data.praiseFlag = !!res.data.length;
    }
    else {
      ElMessage.error(res.msg)
      console.log(res)
    }
  })
}

loadPraise()

const collect = () => {
  request.post('/collect/add', {
    userId: data.user.id,
    relId: data.articleId,
  }).then(res => {
    if (res.code == 200) {
      ElMessage.success('操作成功')
      loadCollect()
    }
    else {
      ElMessage.error(res.msg)
    }
  })
}

const loadCollect = () => {
  request.get('/collect/selectAll', {
    params: {
      userId: data.user.id,
      relId: data.articleId
    }
  }).then(res => {
    if (res.code == 200) {
      data.collectFlag = !!res.data.length;
    }
    else {
      ElMessage.error(res.msg)
    }
  })
}

loadCollect()

const comment = (content) => {
  if (!content) {
    ElMessage.error('请输入评论内容')
    return
  }
  request.post('/comments/add', {
    userId: data.user.id,
    relId: data.articleId,
    content: content,
    fid: data.fid
  }).then(res => {
    if (res.code == 200) {
      ElMessage.success('评论成功')
      data.content = ''
      data.replyContent = ''
      data.fid = 0
      data.dialogVisible = false
      loadComments()
    }
    else {
      ElMessage.error(res.msg)
    }
  })
}

const loadComments = () => {
  request.get('/comments/selectAll',{
    params: {
      relId: data.articleId,
      fid: 0
    }
  }).then(res => {
    if (res.code == 200) {
      data.commentsData = res.data
    }
    else {
      ElMessage.error(res.msg)
    }
  })
}

loadComments()

const replyInit = (fid) => {
  data.fid = fid
  data.dialogVisible = true
}

const addFriend = () => {
  request.post('/friends/add', {
    fromId: data.user.id,
    toId: data.articleData.userId,
    status: "待同意"
  }).then(res => {
    if (res.code == 200) {
      ElMessage.success('操作成功，等待对方同意')
      loadArticle()
    }
    else {
      ElMessage.error(res.msg)
    }
  })
}

</script>
