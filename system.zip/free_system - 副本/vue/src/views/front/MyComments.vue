<!--教师信息页面-->
<template>
  <div class="w-[80%] mx-auto mt-5">

<!--搜索框-->
    <div class="card" style="margin-bottom: 5px;">
      <el-input v-model="data.content" style="width: 300px; margin-right: 10px" placeholder="请输入评论内容查询"></el-input>
      <el-button type="primary" @click="load">查询</el-button>
      <el-button type="info" style="margin: 0 10px" @click="reset">重置</el-button>
    </div>
<!--列表卡片-->
    <div class="card" style="margin-bottom: 5px">
      <el-table :data="data.tableData" stripe tooltip-effect="dark myEffect">
        <el-table-column label="帖子标题" show-overflow-tooltip>
          <template v-slot="scope">
            <a :href="'/front/articleDetail?id=' + scope.row.relId" target="_blank">{{ scope.row.relName }}</a>
          </template>
        </el-table-column>
        <el-table-column label="评论内容" prop="content"></el-table-column>
        <el-table-column label="评论用户" prop="userName"></el-table-column>
        <el-table-column label="评论时间" align="center" prop="time"></el-table-column>
        <el-table-column label="操作" align="center" width="160">
          <template #default="scope">
            <el-button type="danger" @click="handleDelete(scope.row.id)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
    </div>
<!--分页-->
    <div class="card">
      <el-pagination style="display: flex;justify-content: center" @current-change="load" background layout="prev, pager, next" v-model:page-size="data.pageSize" v-model:current-page="data.pageNum" :total="data.total"/>
    </div>
  </div>
</template>

<script setup>
import request from "@/utils/request";
import {reactive} from "vue";
import {ElMessageBox, ElMessage} from "element-plus";
import '@wangeditor/editor/dist/css/style.css' // 引入 css

const data = reactive({
  user: JSON.parse(localStorage.getItem('system-user') || '{}'),
  pageNum: 1,
  pageSize: 5,
  total: 0,
  tableData: [],
  content: null,
})

// 分页查询
const load = () => {
  request.get('/comments/selectPage', {
    params: {
      pageNum: data.pageNum,
      pageSize: data.pageSize,
      content: data.content,
      userId: data.user.id
    }
  }).then(res => {
    data.tableData = res.data?.list
    data.total = res.data?.total
  })
}

// 删除
const handleDelete = (id) => {
  ElMessageBox.confirm('删除后数据无法恢复，您确定删除吗?', '删除确认', { type: 'warning' }).then(res => {
    request.delete('/comments/delete/' + id).then(res => {
      if (res.code === '200') {
        load()
        ElMessage.success('操作成功')
      } else {
        ElMessage.error(res.msg)
      }
    })
  }).catch(err => {})
}

// 重置
const reset = () => {
  data.content = null
  load()
}

load()
</script>

<style>
.myEffect {
  max-width: 30%;
}
</style>