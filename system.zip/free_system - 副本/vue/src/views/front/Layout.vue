<template>
  <div>
    <div style="margin-top: 20px " class="mt-[20px] mx-auto w-[80%] ">
      <el-row :gutter="20">
        <el-col :span="6">
          <div>
            <img src="@/assets/imgs/1.png" class="h-[200px] w-full rounded-[5px]">
            <div style="font-size: 16px;font-weight: bold">常见的反诈方法有哪些呢？</div>
            <div class="w-full flex mt-[10px]">
              <div class="flex flex-1 items-center">
                <img src="@/assets/imgs/2.png" alt="" class="w-5 h-5 rounded-full">
                <div>林和希</div>
              </div>
              <div>2025-11-18 11:01:02</div>
            </div>
          </div>
        </el-col>
        <el-col :span="6">
          <div>
            <img src="@/assets/imgs/3.png" class="h-[200px] w-full rounded-[5px]">
            <div style="font-size: 16px;font-weight: bold">常见的反诈方法有哪些呢？</div>
            <div class="w-full flex mt-[10px]">
              <div class="flex flex-1 items-center">
                <img src="@/assets/imgs/2.png" alt="" class="w-5 h-5 rounded-full">
                <div>林和希</div>
              </div>
              <div>2025-11-18 11:01:02</div>
            </div>
          </div>
        </el-col>
        <el-col :span="6">
          <div>
            <img src="@/assets/imgs/4.png" class="h-[200px] w-full rounded-[5px]">
            <div style="font-size: 16px;font-weight: bold">常见的反诈方法有哪些呢？</div>
            <div class="w-full flex mt-[10px]">
              <div class="flex flex-1 items-center">
                <img src="@/assets/imgs/2.png" alt="" class="w-5 h-5 rounded-full">
                <div>林和希</div>
              </div>
              <div>2025-11-18 11:01:02</div>
            </div>
          </div>
        </el-col>
        <el-col :span="6">
          <div>
            <img src="@/assets/imgs/5.png" class="h-[200px] w-full rounded-[5px]">
            <div style="font-size: 16px;font-weight: bold">常见的反诈方法有哪些呢？</div>
            <div class="w-full flex mt-[10px]">
              <div class="flex flex-1 items-center">
                <img src="@/assets/imgs/2.png" alt="" class="w-5 h-5 rounded-full">
                <div>林和希</div>
              </div>
              <div>2025-11-18 11:01:02</div>
            </div>
          </div>
        </el-col>

      </el-row>
    </div>
  </div>

  <div class="flex w-[70%] bg-red-200 mx-auto mt-9">
    <div class="w-[450px] h-full mr-2">
      <img src="@/assets/imgs/1.png" class=" rounded-[5px]">
      <div class="font-bold">赛事咨询</div>
      <div class="text-xs text-gray-500 mb-2">这是简介这是简介这是简介这是简介</div>
    </div>
    <div class="flex-1">
      <el-row :gutter="20">
        <el-col :span="12">
          <div>
            <img src="@/assets/imgs/1.png" class="h-[200px] w-full rounded-[5px]">
            <div style="font-size: 16px;font-weight: bold">常见的反诈方法有哪些呢？</div>
            <div class="text-xs text-gray-500 mb-2">这是简介这是简介这是简介这是简介</div>
          </div>
        </el-col>
        <el-col :span="12">
          <div>
            <img src="@/assets/imgs/3.png" class="h-[200px] w-full rounded-[5px]">
            <div style="font-size: 16px;font-weight: bold">常见的反诈方法有哪些呢？</div>
            <div class="text-xs text-gray-500 mb-2">这是简介这是简介这是简介这是简介</div>
          </div>
        </el-col>
        <el-col :span="12">
          <div>
            <img src="@/assets/imgs/4.png" class="h-[200px] w-full rounded-[5px]">
            <div style="font-size: 16px;font-weight: bold">常见的反诈方法有哪些呢？</div>
            <div class="text-xs text-gray-500 mb-2">这是简介这是简介这是简介这是简介</div>
          </div>
        </el-col>
        <el-col :span="12">
          <div>
            <img src="@/assets/imgs/5.png" class="h-[200px] w-full rounded-[5px]">
            <div style="font-size: 16px;font-weight: bold">常见的反诈方法有哪些呢？</div>
            <div class="text-xs text-gray-500 mb-2">这是简介这是简介这是简介这是简介</div>
          </div>
        </el-col>

      </el-row>
    </div>
  </div>

</template>
<script lang="ts">
</script>