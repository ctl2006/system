<!--教师信息页面-->
<template>
  <div class="w-[80%] mx-auto mt-5">

<!--搜索框-->
    <div class="card" style="margin-bottom: 5px;">
      <el-input v-model="data.name" style="width: 300px; margin-right: 10px" placeholder="请输入作业名称查询"></el-input>
      <el-button type="primary" @click="load">查询</el-button>
      <el-button type="info" style="margin: 0 10px" @click="reset">重置</el-button>
    </div>
<!--列表卡片-->
    <div class="card" style="margin-bottom: 5px">
      <el-table :data="data.tableData" stripe tooltip-effect="dark myEffect">
        <el-table-column label="名称" prop="name"></el-table-column>
        <el-table-column label="描述" prop="content"></el-table-column>
        <el-table-column label="操作" align="center" width="160">
          <template #default="scope">
            <el-button type="primary" @click="handleAdd(scope.row.id)">提交作业</el-button>
          </template>
        </el-table-column>
      </el-table>
    </div>
<!--分页-->
    <div class="card">
      <el-pagination style="display: flex;justify-content: center" @current-change="load" background layout="prev, pager, next" v-model:page-size="data.pageSize" v-model:current-page="data.pageNum" :total="data.total"/>
    </div>
  </div>

  <el-dialog title="提交作业" width="40%" v-model="data.formVisible" :close-on-click-modal="false" destroy-on-close>
    <el-form :model="data.form" label-width="100px" style="padding-right: 50px">
      <el-form-item label="文件" prop="num">
        <el-upload :action="uploadUrl" list-type="file" :on-success="handleFileSuccess">
          <el-button type="primary">上传文件</el-button>
        </el-upload>
      </el-form-item>
    </el-form>
    <template #footer>
      <span class="dialog-footer">
        <el-button @click="data.formVisible = false">取 消</el-button>
        <el-button type="primary" @click="save">提 交</el-button>
      </span>
    </template>
  </el-dialog>
</template>

<script setup>
import request from "@/utils/request";
import {reactive} from "vue";
import {ElMessageBox, ElMessage} from "element-plus";
import '@wangeditor/editor/dist/css/style.css' // 引入 css

const data = reactive({
  user: JSON.parse(localStorage.getItem('system-user') || '{}'),
  pageNum: 1,
  pageSize: 5,
  total: 0,
  tableData: [],
  name: null,
  form: {},
  formVisible: false,
})

// 分页查询
const load = () => {
  request.get('/homework/selectPage', {
    params: {
      pageNum: data.pageNum,
      pageSize: data.pageSize,
      name: data.name,
      userId: data.user.id
    }
  }).then(res => {
    if (res.code == 200){
      data.tableData = res.data?.list
      data.total = res.data?.total
    }
    else {
      ElMessage.error(res.msg)
    }
  })
}

const handleAdd = (homeworkId) => {
  data.form = {}
  data.formVisible = true
  data.form.userId = data.user.id
  data.form.homeworkId = homeworkId
}

const save = () => {
  request.post('/submit/add', data.form).then(res => {
    console.log(res)
    if (res.code === '200') {
      load()
      ElMessage.success('操作成功')
      data.formVisible = false
    } else {
      ElMessage.error(res.msg)
    }
  })
}

// 文件上传的接口地址
const uploadUrl = import.meta.env.VITE_BASE_URL + '/files/upload'
// 处理文件上传的钩子
const handleFileSuccess = (res) => {
  data.form.file = res.data  // res.data就是文件上传返回的文件路径，获取到路径后赋值表单的属性
}

// 重置
const reset = () => {
  data.name = null
  load()
}

load()
</script>

<style>
.myEffect {
  max-width: 30%;
}
</style>