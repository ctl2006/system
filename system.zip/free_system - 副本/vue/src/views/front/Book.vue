<template>
  <div>
    <div style="margin-top: 20px " class="mt-[20px] mx-auto w-[80%] ">
      <el-row :gutter="20">
        <el-col :span="6" v-for="item in data.bookData" :key="item.id" class="mb-[30px]">
          <div>
            <img :src="item.img" class="h-[200px] w-full rounded-[5px]">
            <div style="font-size: 16px;font-weight: bold">{{item.name}}</div>
            <div class="text-sm mb-3 flex">
              价格：<span style="color: red" class="font-bold">￥{{item.price}}</span>
              <span class="ml-auto">剩余 {{item.num}}本</span>
            </div>
            <div class="w-full flex mt-[5px] text-sm justify-between">
              <div>{{item.author}}</div>
              <div>{{item.publishing}}</div>
            </div>
            <div class="mt-[10px] text-center">
              <el-button size="small" type="primary" @click="borrow(item)">借阅</el-button>
              <el-button size="small" type="success" @click="readInit(item.id)">阅读</el-button>
              <el-button size="small" type="info" @click="buyInit(item.id)" :disabled="item.num === 0">购买</el-button>
            </div>
          </div>
        </el-col>
      </el-row>
    </div>
    <!--分页-->
    <div class="mt-[50px]">
      <el-pagination style="display: flex;justify-content: center" @current-change="loadBook" background layout="total, prev, pager, next" v-model:page-size="data.pageSize" v-model:current-page="data.pageNum" :total="data.total"/>
    </div>
  </div>

  <el-dialog title="购买信息" width="40%" v-model="data.formVisible" :close-on-click-modal="false" destroy-on-close>
    <el-form :model="data.form" label-width="100px" style="padding-right: 50px">
      <el-form-item label="购买数量" prop="num">
        <el-input-number v-model="data.form.num" :min="1" />
      </el-form-item>
      <el-form-item label="收货地址" prop="address">
        <el-input v-model="data.form.address" autocomplete="off" />
      </el-form-item>
      <el-form-item label="联系电话" prop="phone">
        <el-input v-model="data.form.phone" autocomplete="off" />
      </el-form-item>
    </el-form>
    <template #footer>
      <span class="dialog-footer">
        <el-button @click="data.formVisible = false">取 消</el-button>
        <el-button type="primary" @click="buy">下 单</el-button>
      </span>
    </template>
  </el-dialog>

  <el-dialog title="章节信息" width="40%" v-model="data.readVisible" :close-on-click-modal="false" destroy-on-close>
    <div v-for="item in data.chapterData" :key="item.id" class="card flex items-center mb-[10px] h-[30px] cursor-pointer" @click="router.push(`/front/contentDetail?id=${item.id}`)">
      {{item.name}}
    </div>
  </el-dialog>

</template>
<script setup>
import {reactive} from "vue";
import {ElMessage} from "element-plus";
import request from "@/utils/request";
import router from "@/router";

const data = reactive({
    user: JSON.parse(localStorage.getItem('system-user') || '{}'),
    bookData: [],
    chapterData: [],
    pageNum: 1,
    pageSize: 8,
    total: 0,
    form: {},
    formVisible: false,
    readVisible: false
})

const loadBook = () => {
    request.get("/book/selectPage",{
        params:{
            pageNum: data.pageNum,
            pageSize: data.pageSize
        }
    }).then(res => {
        if (res.code === '200') {
            data.bookData = res.data?.list
            data.total = res.data?.total
        }
        else {
          ElMessage.error(res.msg)
        }
    })
}
loadBook()


const borrow = (book) => {
    request.post("/borrow/add", {
      userId: data.user.id,
      bookId: book.id,
      status: "借阅中"
    }).then(res => {
        if (res.code === '200') {
            ElMessage.success("借阅成功")
        }
        else {
            ElMessage.error(res.msg)
        }
    })
}

const buyInit = (id) => {
  data.form = {}
  data.form.relId = id
  data.form.userId = data.user.id
  data.form.status = '待发货'
  data.formVisible = true
}
const buy = () => {
  console.log(data.form)
    request.post("/orders/add", data.form).then(res => {
        if (res.code === '200') {
            ElMessage.success("下单成功，等待发货")
            data.formVisible = false
            loadBook()
        }
        else {
            ElMessage.error(res.msg)
        }
    })
}

const readInit = (bookId) => {
  request.get("/chapter/selectAll" ,{
    params:{
      bookId: bookId
      }
  } ).then(res => {
    if (res.code === '200') {
      data.chapterData = res.data
      data.readVisible = true
      console.log(res.data)
    }
    else {
      ElMessage.error(res.msg)
    }
  })
}


</script>