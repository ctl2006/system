<template>
  <div>
    <div class="w-[50%] mt-[2%] bg-yellow-100 mx-auto border-solid border-2 border-black px-[5%] py-[2%]" v-for="item in data.bookContent" v-html="item.content"></div>
    <!--分页-->
    <div class="my-[40px]">
      <el-pagination style="display: flex;justify-content: center" @current-change="loadBookContent" background layout="prev, next" prev-text="上一页" next-text="下一页" v-model:page-size="data.pageSize" v-model:current-page="data.pageNum" :total="data.total"/>
    </div>
  </div>

</template>
<script setup>
import {reactive} from "vue";
import {ElMessage} from "element-plus";
import request from "@/utils/request";
import router from "@/router";

const data = reactive({
  user: JSON.parse(localStorage.getItem('system-user') || '{}'),
  chapterId: router.currentRoute.value.query.id,
  bookContent: [],
  total: 0,
  pageNum: 1,
  pageSize: 1
})

const loadBookContent = () => {
  request.get('/bookContent/selectPage', {
    params: {
      chapterId: data.chapterId,
      pageNum: data.pageNum,
      pageSize: data.pageSize
    }
  }).then(res => {
    if (res.code === '200') {
      data.bookContent = res.data?.list
      data.total = res.data.total
    }
    else {
      ElMessage.error(res.msg)
    }
    })
  }
  loadBookContent()
</script>