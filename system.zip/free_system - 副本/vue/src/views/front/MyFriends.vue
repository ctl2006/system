<!--教师信息页面-->
<template>
  <div class="w-[80%] mx-auto mt-5">

<!--列表卡片-->
    <div class="card" style="margin-bottom: 5px">
      <div class="font-bold my-[5px] mx-[5px]">我的好友</div>

      <el-table :data="data.tableData" stripe tooltip-effect="dark myEffect">
        <el-table-column label="好友名称">
          <template #default="scope">
            <span v-if="scope.row.fromId === data.user.id">{{scope.row.toUser.name}}</span>
            <span v-if="scope.row.toId === data.user.id">{{scope.row.fromUser.name}}</span>
          </template>
        </el-table-column>
        <el-table-column label="好友状态" prop="status">
          <template #default="scope">
            <el-tag type="success" v-if="scope.row.status === '已同意'">{{scope.row.status}}</el-tag>
          </template>
        </el-table-column>
        <el-table-column label="操作" align="center" width="250">
          <template #default="scope">
            <el-button type="danger" @click="handleDelete(scope.row.id)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
    </div>
<!--分页-->
    <div class="card">
      <el-pagination style="display: flex;justify-content: center" @current-change="load" background layout="prev, pager, next" v-model:page-size="data.pageSize" v-model:current-page="data.pageNum" :total="data.total"/>
    </div>
  </div>
</template>

<script setup>
import request from "@/utils/request";
import {reactive} from "vue";
import {ElMessageBox, ElMessage} from "element-plus";
import '@wangeditor/editor/dist/css/style.css' // 引入 css

const data = reactive({
  user: JSON.parse(localStorage.getItem('system-user') || '{}'),
  pageNum: 1,
  pageSize: 5,
  total: 0,
  tableData: [],
})

// 分页查询
const load = () => {
  request.get('/friends/selectMyFriendsPage', {
    params: {
      pageNum: data.pageNum,
      pageSize: data.pageSize,
      userId: data.user.id,
    }
  }).then(res => {
    if (res.code === '200'){
      data.tableData = res.data?.list
      data.total = res.data?.total
    }
    else {
      ElMessage.error(res.msg)
    }
  })
}

// 删除
const handleDelete = (id) => {
  ElMessageBox.confirm('删除后数据无法恢复，您确定删除吗?', '删除确认', { type: 'warning' }).then(res => {
    request.delete('/friends/delete/' + id).then(res => {
      if (res.code === '200') {
        load()
        ElMessage.success('操作成功')
      } else {
        ElMessage.error(res.msg)
      }
    })
  }).catch(err => {})
}



load()
</script>

<style>
.myEffect {
  max-width: 30%;
}
</style>