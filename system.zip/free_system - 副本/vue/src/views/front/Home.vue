<template>
  <div class="w-[50%] my-[20px] mx-auto min-h-[100vh]">

<!--    父评论-->
    <div>
      <el-input type="textarea" :rows="5" v-model="data.content" placeholder="您此刻有没有什么想要分享的？"></el-input>
    </div>
    <div class="my-[10px] flex gap-[10px] justify-between">
      <el-upload :action="uploadUrl" v-model:file-list="data.fileList" list-type="picture" :on-success="handleImgSuccess">
        <el-button type="success">上传图片</el-button>
      </el-upload>
      <el-button type="primary" @click="submit(data.content)">发布</el-button>
    </div>
    <div class="mb-7">
      看看大家都发了什么
    </div>
    <div>
      <div v-for="item in data.chatData" :key="item.id" class="flex mb-3">
        <img :src="item.userAvatar" class="w-[40px] h-[40px] rounded-[50%] mr-3">
        <div>
          <div class="font-bold">{{item.userName}}</div>
          <div class="mt-[10px] break-all">{{item.content}}</div>
          <div v-if="item.img">
            <img :src="item.img" class="w-[50px] h-[50px] rounded-[5px] mt-[5px]">
          </div>
          <div class="mt-[10px] text-sm text-gray-500">发布时间：{{item.time}}</div>
          <div>
            <el-button type="text" @click="">点赞</el-button>
            <el-button type="text" @click="replyInit(item.id)">回复</el-button>
          </div>

          <!--子评论-->
          <div class=" mt-[20px]">
            <div v-for="(it, index) in item.children" :key="index">
              <div class="flex gap-[20px] w-full mt-[10px]">
                <img :src="it.userAvatar" class="w-[50px] h-[50px] rounded-[50%]">
                <div>
                  <div><span class="font-bold">{{it.userName}}</span> 回复：</div>
                  <div class="mt-[10px] break-all" >{{it.content}}</div>
                  <div v-if="it.img">
                    <img :src="it.img" class="w-[50px] h-[50px] rounded-[5px] mt-[5px]">
                  </div>
                  <div class="mt-[5px] text-gray-500 text-sm flex items-center">
                    <span class="mr-[20px]">{{it.time}}</span>
                    <el-button type="text" size="small" @click="replyInit(it.id)">回复</el-button>
                  </div>
                </div>
              </div>
            </div>
          </div>

        </div>
      </div>
    </div>
    <!--分页-->
    <div class="mt-[50px]">
      <el-pagination style="display: flex;justify-content: center" @current-change="load" background layout="total, prev, pager, next" v-model:page-size="data.pageSize" v-model:current-page="data.pageNum" :total="data.total"/>
    </div>
  </div>

  <el-dialog title="回复" width="40%" v-model="data.dialogVisible" :close-on-click-modal="false" destroy-on-close>
    <div class="mt-[10px]">
      <el-input v-model="data.replyContent" :row="4" type="textarea" placeholder="请输入评论内容"  />
    </div>
    <template #footer>
      <span class="dialog-footer">
      <div class="my-[10px] flex gap-[10px] justify-between">
        <el-upload :action="uploadUrl" v-model:file-list="data.fileList1" list-type="picture" :on-success="handleImgSuccess">
          <el-button type="success">上传图片</el-button>
        </el-upload>
        <el-button type="primary" @click="submit(data.replyContent)">发布</el-button>
      </div>
      </span>
    </template>
  </el-dialog>
</template>

<script setup>
import request from "@/utils/request";
import {reactive} from "vue";
import router from "@/router";
import {ElMessage} from "element-plus";

const data = reactive({
  user: JSON.parse(localStorage.getItem('system-user') || '{}'),
  pageNum: 1,
  pageSize: 2,
  total: 0,
  fid: 0,
  content: null,
  replyContent: null,
  form: {},
  chatData: [],
  fileList:[],
  fileList1:[],
  dialogVisible: false,
})


// 文件上传的接口地址
const uploadUrl = import.meta.env.VITE_BASE_URL + '/files/upload'
// 处理文件上传的钩子
const handleImgSuccess = (res) => {
  ElMessage.success('上传成功')
  data.form.img = res.data  // res.data就是文件上传返回的文件路径，获取到路径后赋值表单的属性
}


const submit = (content) =>{
  if (!content) {
    ElMessage.error('请输入内容')
    return
  }
  data.form.content = content
  data.form.userId = data.user.id
  data.form.fid = data.fid
  request.post('/chat/add', data.form).then(res => {
    console.log(res)
    if (res.code === '200') {
      ElMessage.success('操作成功')
      data.content = null
      data.form = {}
      data.fileList = []
      data.fileList1 = []
      data.dialogVisible = false
      data.fid = 0
      load()
    } else {
      ElMessage.error(res.msg)
    }
  })
}


const load = () => {
  request.get('/chat/selectPage', {
    params: {
      pageNum: data.pageNum,
      pageSize: data.pageSize,
      fid: 0,
    }
  }).then(res => {
    console.log(res)
    if (res.code === '200'){
      data.chatData = res.data?.list
      data.total = res.data?.total
    }
    else {
      ElMessage.error(res.msg)
    }
  })
}


const replyInit = (fid) => {
  data.fid = fid
  data.dialogVisible = true
}


load()
</script>